/*
  # Biohacking Platform Initial Schema

  ## Overview
  This migration creates the complete database schema for a biohacking and self-optimization platform
  with AI chat, tracking metrics, gamification, and psychiatry support.

  ## New Tables

  ### 1. `profiles`
  - Extended user profile information
  - `id` (uuid, references auth.users)
  - `user_id` (uuid, unique reference to auth.users)
  - `name` (text)
  - `height_cm` (numeric)
  - `gender` (text)
  - `weight_kg` (numeric)
  - `date_of_birth` (date)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. `gamification`
  - User gamification data
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `xp` (integer)
  - `level` (integer)
  - `badges` (jsonb array)
  - `current_streak` (integer)
  - `longest_streak` (integer)
  - `updated_at` (timestamptz)

  ### 3. `daily_metrics`
  - Daily tracking data for all biohacking metrics
  - All 18 tracking fields as specified
  - Unique constraint on user_id + date

  ### 4. `chat_history`
  - Stores all chat interactions
  - Supports multiple chat modes (biohacking, mindset, psychiatry)
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `mode` (text: biohacking, stoic, motivational, psychiatry_talk, psychiatry_diagnostic)
  - `message` (text)
  - `role` (text: user or assistant)
  - `created_at` (timestamptz)

  ### 5. `psychiatry_assessments`
  - Structured diagnostic summaries
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `symptoms` (jsonb)
  - `severity` (text)
  - `structured_summary` (text)
  - `completed_at` (timestamptz)

  ## Security
  - RLS enabled on all tables
  - Users can only access their own data
  - Separate policies for SELECT, INSERT, UPDATE, DELETE
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  height_cm numeric DEFAULT 0,
  gender text DEFAULT '',
  weight_kg numeric DEFAULT 0,
  date_of_birth date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create gamification table
CREATE TABLE IF NOT EXISTS gamification (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  xp integer DEFAULT 0,
  level integer DEFAULT 1,
  badges jsonb DEFAULT '[]'::jsonb,
  current_streak integer DEFAULT 0,
  longest_streak integer DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE gamification ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own gamification"
  ON gamification FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own gamification"
  ON gamification FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own gamification"
  ON gamification FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create daily_metrics table
CREATE TABLE IF NOT EXISTS daily_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  meditation_time_minutes integer DEFAULT 0,
  journaling_time_minutes integer DEFAULT 0,
  stress_level_1_10 integer DEFAULT 5,
  mood_score_1_10 integer DEFAULT 5,
  sleep_quality_1_10 integer DEFAULT 5,
  water_intake_liters numeric DEFAULT 0,
  steps_per_day integer DEFAULT 0,
  exercise_minutes integer DEFAULT 0,
  resting_heart_rate_bpm integer DEFAULT 0,
  weight_kg numeric DEFAULT 0,
  energy_level_1_10 integer DEFAULT 5,
  meals_eaten integer DEFAULT 0,
  protein_intake_grams numeric DEFAULT 0,
  fruit_vegetable_servings integer DEFAULT 0,
  sugar_alcohol_consumption text DEFAULT '',
  deep_work_hours numeric DEFAULT 0,
  reading_time_minutes integer DEFAULT 0,
  study_time_minutes integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

ALTER TABLE daily_metrics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own metrics"
  ON daily_metrics FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own metrics"
  ON daily_metrics FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own metrics"
  ON daily_metrics FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own metrics"
  ON daily_metrics FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create chat_history table
CREATE TABLE IF NOT EXISTS chat_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mode text NOT NULL DEFAULT 'biohacking',
  message text NOT NULL,
  role text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own chat history"
  ON chat_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own chat messages"
  ON chat_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own chat history"
  ON chat_history FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create psychiatry_assessments table
CREATE TABLE IF NOT EXISTS psychiatry_assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  symptoms jsonb DEFAULT '{}'::jsonb,
  severity text DEFAULT '',
  structured_summary text DEFAULT '',
  completed_at timestamptz DEFAULT now()
);

ALTER TABLE psychiatry_assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own assessments"
  ON psychiatry_assessments FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own assessments"
  ON psychiatry_assessments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_daily_metrics_user_date ON daily_metrics(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_chat_history_user_mode ON chat_history(user_id, mode, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_psychiatry_assessments_user ON psychiatry_assessments(user_id, completed_at DESC);