/*
  # Add Goals and Voice Chat Features

  ## Overview
  Adds user goals management and voice chat session tracking to support AI voice assistant
  that keeps user goals in context.

  ## New Tables

  ### 1. `user_goals`
  - Stores user's goals for the AI to reference in conversations
  - `id` (uuid, primary key)
  - `user_id` (uuid, references auth.users)
  - `goal_type` (text: short_term, long_term, health, mental, productivity)
  - `title` (text)
  - `description` (text)
  - `target_date` (date)
  - `status` (text: active, completed, paused)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. `voice_sessions`
  - Tracks voice chat sessions for analytics
  - `id` (uuid, primary key)
  - `user_id` (uuid, references auth.users)
  - `duration_seconds` (integer)
  - `transcript` (text)
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on all tables
  - Users can only access their own goals and voice sessions
*/

-- Create user_goals table
CREATE TABLE IF NOT EXISTS user_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  goal_type text NOT NULL DEFAULT 'health',
  title text NOT NULL,
  description text DEFAULT '',
  target_date date,
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_goals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own goals"
  ON user_goals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own goals"
  ON user_goals FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own goals"
  ON user_goals FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own goals"
  ON user_goals FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create voice_sessions table
CREATE TABLE IF NOT EXISTS voice_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  duration_seconds integer DEFAULT 0,
  transcript text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE voice_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own voice sessions"
  ON voice_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own voice sessions"
  ON voice_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_user_goals_user_status ON user_goals(user_id, status);
CREATE INDEX IF NOT EXISTS idx_voice_sessions_user ON voice_sessions(user_id, created_at DESC);