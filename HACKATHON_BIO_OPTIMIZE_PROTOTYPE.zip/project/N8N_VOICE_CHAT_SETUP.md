# N8N Voice Chat Integration Guide

This guide explains how to connect n8n workflows to the Voice Chat feature in your BioOptimize app.

## Overview

The Voice Chat feature can be enhanced with n8n to:
- Transcribe audio using AI services (OpenAI Whisper, AssemblyAI, etc.)
- Process conversations with AI (OpenAI GPT, Anthropic Claude, etc.)
- Store transcripts in your database
- Trigger automated workflows based on conversation content
- Send summaries via email/SMS
- Integrate with other tools (Notion, Airtable, etc.)

## Architecture

```
User Voice Input → Frontend → n8n Webhook → AI Services → Response → Frontend Display
                                    ↓
                              Store in Supabase
                                    ↓
                              Trigger Workflows
```

## Step 1: Set Up n8n

### Option A: n8n Cloud (Easiest)
1. Go to [n8n.cloud](https://n8n.cloud)
2. Sign up for a free account
3. Your webhook URL will be: `https://your-username.app.n8n.cloud/webhook/...`

### Option B: Self-Hosted
1. Install n8n:
```bash
npx n8n
# or with Docker
docker run -it --rm --name n8n -p 5678:5678 n8nio/n8n
```
2. Access at `http://localhost:5678`
3. For production, deploy to Railway, Render, or DigitalOcean
4. Use a tunnel service like ngrok for local testing:
```bash
ngrok http 5678
```

## Step 2: Create Voice Chat Workflow in n8n

### Workflow Structure

**Node 1: Webhook (Trigger)**
- Method: POST
- Path: `/webhook/voice-chat`
- Response: Immediately
- Receive JSON body with:
  - `userId` - User identifier
  - `audioData` - Base64 encoded audio or audio URL
  - `audioFormat` - Format (webm, mp3, wav, etc.)
  - `sessionId` - Unique session identifier

**Node 2: Audio Transcription**

Choose one of these services:

**Option A: OpenAI Whisper**
- Use HTTP Request node
- URL: `https://api.openai.com/v1/audio/transcriptions`
- Method: POST (multipart/form-data)
- Headers: `Authorization: Bearer YOUR_OPENAI_API_KEY`
- Body:
  - `file`: audio file
  - `model`: "whisper-1"
  - `language`: "en" (optional)

**Option B: AssemblyAI**
- First upload audio via HTTP Request
- URL: `https://api.assemblyai.com/v2/upload`
- Then request transcription
- URL: `https://api.assemblyai.com/v2/transcript`

**Option C: Google Speech-to-Text**
- Use Google Cloud node
- Service: Speech-to-Text
- Operation: Recognize

**Node 3: Process with AI**

**Option A: OpenAI GPT**
- Node: OpenAI Chat Model
- Model: gpt-4 or gpt-3.5-turbo
- System Prompt: "You are a health and wellness coach..."
- User Message: `{{ $json.transcript }}`

**Option B: Anthropic Claude**
- Use HTTP Request node
- URL: `https://api.anthropic.com/v1/messages`
- Headers:
  - `x-api-key`: YOUR_ANTHROPIC_KEY
  - `anthropic-version`: "2023-06-01"
- Body:
```json
{
  "model": "claude-3-5-sonnet-20241022",
  "max_tokens": 1024,
  "messages": [
    {
      "role": "user",
      "content": "{{ $json.transcript }}"
    }
  ],
  "system": "You are a compassionate health coach..."
}
```

**Node 4: Store in Supabase**
- Node: HTTP Request
- URL: `YOUR_SUPABASE_URL/rest/v1/voice_chat_sessions`
- Method: POST
- Headers:
  - `apikey`: YOUR_SUPABASE_ANON_KEY
  - `Authorization`: Bearer YOUR_SUPABASE_ANON_KEY
  - `Content-Type`: application/json
- Body:
```json
{
  "user_id": "{{ $json.userId }}",
  "session_id": "{{ $json.sessionId }}",
  "transcript": "{{ $json.transcript }}",
  "ai_response": "{{ $json.aiResponse }}",
  "audio_duration_seconds": "{{ $json.duration }}",
  "created_at": "{{ $now }}"
}
```

**Node 5: Return Response**
- Node: Respond to Webhook
- Body:
```json
{
  "transcript": "{{ $json.transcript }}",
  "response": "{{ $json.aiResponse }}",
  "sessionId": "{{ $json.sessionId }}"
}
```

### Example n8n Workflow (JSON)

Here's a complete workflow you can import:

```json
{
  "nodes": [
    {
      "parameters": {
        "httpMethod": "POST",
        "path": "voice-chat",
        "responseMode": "responseNode"
      },
      "name": "Webhook",
      "type": "n8n-nodes-base.webhook",
      "position": [250, 300]
    },
    {
      "parameters": {
        "url": "https://api.openai.com/v1/audio/transcriptions",
        "sendHeaders": true,
        "headerParameters": {
          "parameters": [
            {
              "name": "Authorization",
              "value": "Bearer YOUR_OPENAI_KEY"
            }
          ]
        },
        "sendBody": true,
        "contentType": "multipart-form-data",
        "bodyParameters": {
          "parameters": [
            {
              "name": "file",
              "value": "={{ $json.audioData }}"
            },
            {
              "name": "model",
              "value": "whisper-1"
            }
          ]
        }
      },
      "name": "Transcribe Audio",
      "type": "n8n-nodes-base.httpRequest",
      "position": [450, 300]
    },
    {
      "parameters": {
        "model": "gpt-4",
        "messages": {
          "values": [
            {
              "role": "system",
              "content": "You are a supportive health and wellness coach."
            },
            {
              "role": "user",
              "content": "={{ $json.text }}"
            }
          ]
        }
      },
      "name": "AI Response",
      "type": "@n8n/n8n-nodes-langchain.openAi",
      "position": [650, 300]
    },
    {
      "parameters": {
        "respondWith": "json",
        "responseBody": "={{ { transcript: $('Transcribe Audio').item.json.text, response: $json.message.content } }}"
      },
      "name": "Respond to Webhook",
      "type": "n8n-nodes-base.respondToWebhook",
      "position": [850, 300]
    }
  ],
  "connections": {
    "Webhook": {
      "main": [[{ "node": "Transcribe Audio", "type": "main", "index": 0 }]]
    },
    "Transcribe Audio": {
      "main": [[{ "node": "AI Response", "type": "main", "index": 0 }]]
    },
    "AI Response": {
      "main": [[{ "node": "Respond to Webhook", "type": "main", "index": 0 }]]
    }
  }
}
```

## Step 3: Get Your Webhook URL

After creating the workflow:

1. **Activate the workflow** (toggle switch in top-right)
2. **Click on the Webhook node**
3. **Copy the Production URL**
   - Should look like: `https://your-instance.app.n8n.cloud/webhook/voice-chat`

## Step 4: Configure Your App

Add the webhook URL to your `.env` file:

```env
VITE_N8N_VOICE_WEBHOOK_URL=https://your-instance.app.n8n.cloud/webhook/voice-chat
```

## Step 5: Update Frontend Code

The app already has voice chat support. To enhance it with n8n:

### Current Implementation Location
`src/components/VoiceChatView.tsx` - This component handles voice recording

### How It Works

1. **User clicks record button** → Starts recording audio
2. **User clicks stop** → Stops recording
3. **Audio is processed** → Converted to appropriate format
4. **Sent to n8n webhook** → POST request with audio data
5. **n8n processes** → Transcribes and generates response
6. **Response displayed** → Shows transcript and AI response

### Expected Request Format from Frontend

```javascript
const response = await fetch(VITE_N8N_VOICE_WEBHOOK_URL, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    userId: user.id,
    audioData: base64Audio, // or URL to audio file
    audioFormat: 'webm',
    sessionId: crypto.randomUUID(),
    timestamp: new Date().toISOString()
  })
});

const data = await response.json();
// { transcript: "...", response: "...", sessionId: "..." }
```

## Step 6: Advanced Features

### Text-to-Speech for AI Response

Add a TTS node after AI response:

**ElevenLabs TTS**
```javascript
// In n8n HTTP Request node
URL: https://api.elevenlabs.io/v1/text-to-speech/VOICE_ID
Method: POST
Headers: {
  "xi-api-key": "YOUR_ELEVENLABS_KEY"
}
Body: {
  "text": "{{ $json.aiResponse }}",
  "model_id": "eleven_monolingual_v1"
}
```

### Conversation Memory

Store conversation history:

```javascript
// Add to Supabase node
{
  "conversation_history": "={{ $json.previousMessages }}",
  "current_turn": "={{ $json.turnNumber }}"
}
```

### Real-Time Processing

For streaming responses:
1. Use Server-Sent Events (SSE) in n8n
2. Stream chunks as they're generated
3. Display progressively in frontend

### Multi-Language Support

```javascript
// In transcription node
{
  "language": "{{ $json.detectedLanguage }}",
  "translate": true
}
```

## Testing Your Integration

### Test with Webhook Testing Tools

**Using cURL:**
```bash
curl -X POST https://your-n8n-url/webhook/voice-chat \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "test-user",
    "audioData": "test-audio-base64",
    "audioFormat": "webm",
    "sessionId": "test-session-123"
  }'
```

**Using Postman:**
1. Create new POST request
2. URL: Your webhook URL
3. Body: JSON with test data
4. Send and verify response

### Monitor n8n Executions

In n8n dashboard:
1. Go to "Executions" tab
2. See real-time execution logs
3. Debug any errors
4. View data flow between nodes

## Troubleshooting

### Issue: Webhook not receiving data
- Check if workflow is activated
- Verify webhook URL is correct in .env
- Check CORS settings if calling from browser

### Issue: Audio transcription fails
- Verify audio format is supported
- Check API key is valid
- Ensure audio file size is within limits

### Issue: AI response is empty
- Check AI service API quota
- Verify prompt is being passed correctly
- Review AI service error logs

### Issue: Supabase insert fails
- Verify table schema matches data
- Check RLS policies allow insert
- Confirm Supabase credentials are correct

## Cost Optimization

### Free Tier Options
- **n8n Cloud**: 5,000 executions/month free
- **OpenAI Whisper**: ~$0.006 per minute
- **OpenAI GPT-3.5**: ~$0.002 per 1K tokens
- **AssemblyAI**: First 3 hours free, then $0.00025/second

### Reduce Costs
1. **Cache responses** for common questions
2. **Compress audio** before sending
3. **Use shorter AI models** (gpt-3.5 vs gpt-4)
4. **Batch process** multiple recordings
5. **Set max audio duration** limits

## Security Best Practices

1. **Validate inputs** in n8n workflow
2. **Rate limit** webhook endpoints
3. **Encrypt sensitive data** in transit
4. **Use environment variables** for API keys
5. **Implement user authentication** tokens
6. **Sanitize AI responses** before displaying
7. **Set up monitoring** and alerts

## Next Steps

Once basic integration works:
- Add sentiment analysis
- Create conversation summaries
- Generate action items from conversations
- Send follow-up emails
- Integrate with calendar for scheduling
- Build analytics dashboard for conversations

## Resources

- [n8n Documentation](https://docs.n8n.io/)
- [OpenAI Whisper API](https://platform.openai.com/docs/guides/speech-to-text)
- [Anthropic Claude API](https://docs.anthropic.com/)
- [Supabase API Docs](https://supabase.com/docs/guides/api)
- [ElevenLabs TTS](https://elevenlabs.io/docs)

---

**Need help?** Check your n8n execution logs and browser console for detailed error messages.
