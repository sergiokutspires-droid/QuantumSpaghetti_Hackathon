import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  user_id: string;
  name: string;
  height_cm: number;
  gender: string;
  weight_kg: number;
  date_of_birth: string | null;
  created_at: string;
  updated_at: string;
};

export type Gamification = {
  id: string;
  user_id: string;
  xp: number;
  level: number;
  badges: string[];
  current_streak: number;
  longest_streak: number;
  updated_at: string;
};

export type DailyMetrics = {
  id: string;
  user_id: string;
  date: string;
  meditation_time_minutes: number;
  journaling_time_minutes: number;
  stress_level_1_10: number;
  mood_score_1_10: number;
  sleep_quality_1_10: number;
  water_intake_liters: number;
  steps_per_day: number;
  exercise_minutes: number;
  resting_heart_rate_bpm: number;
  weight_kg: number;
  energy_level_1_10: number;
  meals_eaten: number;
  protein_intake_grams: number;
  fruit_vegetable_servings: number;
  sugar_alcohol_consumption: string;
  deep_work_hours: number;
  reading_time_minutes: number;
  study_time_minutes: number;
  created_at: string;
  updated_at: string;
};

export type ChatMessage = {
  id: string;
  user_id: string;
  mode: string;
  message: string;
  role: 'user' | 'assistant';
  created_at: string;
};

export type PsychiatryAssessment = {
  id: string;
  user_id: string;
  symptoms: Record<string, unknown>;
  severity: string;
  structured_summary: string;
  completed_at: string;
};

export type UserGoal = {
  id: string;
  user_id: string;
  goal_type: string;
  title: string;
  description: string;
  target_date: string | null;
  status: string;
  created_at: string;
  updated_at: string;
};

export type VoiceSession = {
  id: string;
  user_id: string;
  duration_seconds: number;
  transcript: string;
  created_at: string;
};
