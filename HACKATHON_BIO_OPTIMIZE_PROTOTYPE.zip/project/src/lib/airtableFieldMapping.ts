export const AIRTABLE_FIELD_NAMES = {
  GOAL: 'Goal',
  GOAL_DESCRIPTION: 'Goal_Description',
  WEEK_1: 'Week_1',
  WEEK_2: 'Week_2',
  WEEK_3: 'Week_3',
  WEEK_4: 'Week_4',
  STATUS: 'Status',
  PROGRESS: 'Progress',
} as const;

export const STATUS_OPTIONS = {
  NOT_STARTED: 'Not Started',
  IN_PROGRESS: 'In Progress',
  DONE: 'Done',
} as const;

export type StatusType = typeof STATUS_OPTIONS[keyof typeof STATUS_OPTIONS];
