import { Goal } from '../types/airtableGoal';
import { STATUS_OPTIONS } from './airtableFieldMapping';

export const mockGoals: Goal[] = [
  {
    id: 'rec1',
    title: 'Complete 5K Running Challenge',
    description: 'Train to run a full 5K without stopping by the end of the month',
    week1: `# Week 1: Foundation Building
- Run/walk 1.5km three times this week
- Focus on proper breathing technique
- Stretch for 10 minutes after each session
- Track your time and distance
- Stay hydrated throughout the day`,
    week2: `# Week 2: Building Endurance
- Increase to 2km runs three times
- Add hill training once this week
- Practice interval running (1 min fast, 2 min slow)
- Continue stretching routine
- Monitor your resting heart rate`,
    week3: `# Week 3: Pushing Limits
- Run 3km twice and 2.5km once
- Incorporate speed work
- Focus on pacing consistency
- Add core strengthening exercises
- Rest one full day between runs`,
    week4: `# Week 4: Race Ready
- Complete one 4km practice run
- Do a full 5K time trial
- Focus on mental preparation
- Taper your training before race day
- Plan your race-day strategy`,
    status: STATUS_OPTIONS.IN_PROGRESS,
    progress: 45,
    createdTime: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    lastModified: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'rec2',
    title: 'Learn TypeScript Fundamentals',
    description: 'Master TypeScript basics and build 3 projects',
    week1: `# Week 1: Basics & Setup
- Install TypeScript and set up development environment
- Learn basic types: string, number, boolean, array
- Practice type annotations
- Complete 10 coding exercises
- Read official TypeScript handbook chapters 1-3`,
    week2: `# Week 2: Advanced Types
- Study interfaces and type aliases
- Learn about union and intersection types
- Practice with generics
- Build a simple typed calculator app
- Review real-world TypeScript code on GitHub`,
    week3: `# Week 3: Real-World Application
- Convert a JavaScript project to TypeScript
- Learn about decorators and modules
- Practice with third-party library types
- Build a typed REST API client
- Debug common TypeScript errors`,
    week4: `# Week 4: Best Practices & Final Project
- Study TypeScript best practices
- Learn about type guards and assertions
- Build a complete TypeScript application
- Set up strict mode and fix all errors
- Document your learning journey`,
    status: STATUS_OPTIONS.NOT_STARTED,
    progress: 0,
    createdTime: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    lastModified: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'rec3',
    title: 'Daily Meditation Practice',
    description: 'Establish a consistent 20-minute daily meditation routine',
    week1: `# Week 1: Getting Started
- Meditate for 5 minutes each morning
- Set up a dedicated meditation space
- Try different meditation apps
- Learn basic breathing techniques
- Journal about your experience`,
    week2: `# Week 2: Building Consistency
- Increase to 10 minutes daily
- Practice body scan meditation
- Meditate at the same time each day
- Learn about different meditation styles
- Track your mood before and after`,
    week3: `# Week 3: Deepening Practice
- Meditate for 15 minutes daily
- Try guided loving-kindness meditation
- Practice mindfulness during daily activities
- Read a book on meditation
- Attend an online meditation group`,
    week4: `# Week 4: Full Practice
- Reach 20-minute daily sessions
- Practice silent meditation
- Reflect on your progress
- Establish your ongoing routine
- Share your experience with others`,
    status: STATUS_OPTIONS.DONE,
    progress: 100,
    createdTime: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    lastModified: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
  },
];
