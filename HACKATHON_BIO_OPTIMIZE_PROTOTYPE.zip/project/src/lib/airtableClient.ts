import {
  AirtableRecord,
  AirtableListResponse,
  AirtableUpdatePayload,
  Goal,
} from '../types/airtableGoal';
import { AIRTABLE_FIELD_NAMES, STATUS_OPTIONS } from './airtableFieldMapping';

const BASE_URL = 'https://api.airtable.com/v0';

class AirtableClient {
  private apiKey: string;
  private baseId: string;
  private tableId: string;
  private viewId: string;

  constructor() {
    this.apiKey = import.meta.env.VITE_AIRTABLE_API_KEY || '';
    this.baseId = import.meta.env.VITE_AIRTABLE_BASE_ID || '';
    this.tableId = import.meta.env.VITE_AIRTABLE_TABLE_ID || '';
    this.viewId = import.meta.env.VITE_AIRTABLE_VIEW_ID || '';
  }

  isConfigured(): boolean {
    return !!(
      this.apiKey &&
      this.apiKey !== 'your-airtable-personal-access-token' &&
      this.baseId &&
      this.tableId
    );
  }

  private getHeaders(): HeadersInit {
    return {
      Authorization: `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
    };
  }

  private async fetchWithRetry(
    url: string,
    options: RequestInit,
    retries = 3,
    backoff = 1000
  ): Promise<Response> {
    try {
      const response = await fetch(url, options);

      if (response.status === 429 && retries > 0) {
        const retryAfter = response.headers.get('Retry-After');
        const delay = retryAfter ? parseInt(retryAfter) * 1000 : backoff;
        await new Promise((resolve) => setTimeout(resolve, delay));
        return this.fetchWithRetry(url, options, retries - 1, backoff * 2);
      }

      return response;
    } catch (error) {
      if (retries > 0) {
        await new Promise((resolve) => setTimeout(resolve, backoff));
        return this.fetchWithRetry(url, options, retries - 1, backoff * 2);
      }
      throw error;
    }
  }

  async listGoals(): Promise<Goal[]> {
    if (!this.isConfigured()) {
      throw new Error('Airtable not configured');
    }

    const allRecords: AirtableRecord[] = [];
    let offset: string | undefined;

    do {
      const url = new URL(`${BASE_URL}/${this.baseId}/${this.tableId}`);
      if (this.viewId) {
        url.searchParams.append('view', this.viewId);
      }
      if (offset) {
        url.searchParams.append('offset', offset);
      }

      const response = await this.fetchWithRetry(url.toString(), {
        method: 'GET',
        headers: this.getHeaders(),
      });

      if (!response.ok) {
        throw new Error(`Airtable API error: ${response.status} ${response.statusText}`);
      }

      const data: AirtableListResponse = await response.json();
      allRecords.push(...data.records);
      offset = data.offset;
    } while (offset);

    return allRecords.map(this.mapRecordToGoal);
  }

  async updateGoal(
    recordId: string,
    updates: Partial<AirtableUpdatePayload['fields']>
  ): Promise<Goal> {
    if (!this.isConfigured()) {
      throw new Error('Airtable not configured');
    }

    const url = `${BASE_URL}/${this.baseId}/${this.tableId}/${recordId}`;

    const response = await this.fetchWithRetry(url, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify({ fields: updates }),
    });

    if (!response.ok) {
      throw new Error(`Airtable API error: ${response.status} ${response.statusText}`);
    }

    const record: AirtableRecord = await response.json();
    return this.mapRecordToGoal(record);
  }

  private mapRecordToGoal(record: AirtableRecord): Goal {
    const fields = record.fields;
    return {
      id: record.id,
      title: fields[AIRTABLE_FIELD_NAMES.GOAL] || 'Untitled Goal',
      description: fields[AIRTABLE_FIELD_NAMES.GOAL_DESCRIPTION] || '',
      week1: fields[AIRTABLE_FIELD_NAMES.WEEK_1] || 'No details yet',
      week2: fields[AIRTABLE_FIELD_NAMES.WEEK_2] || 'No details yet',
      week3: fields[AIRTABLE_FIELD_NAMES.WEEK_3] || 'No details yet',
      week4: fields[AIRTABLE_FIELD_NAMES.WEEK_4] || 'No details yet',
      status: fields[AIRTABLE_FIELD_NAMES.STATUS] || STATUS_OPTIONS.NOT_STARTED,
      progress: fields[AIRTABLE_FIELD_NAMES.PROGRESS] || 0,
      createdTime: record.createdTime,
      lastModified: record.createdTime,
    };
  }
}

export const airtableClient = new AirtableClient();
