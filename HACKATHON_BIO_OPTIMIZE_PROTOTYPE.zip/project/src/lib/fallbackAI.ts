import { UserGoal, DailyMetrics } from './supabase';

export function generateFallbackResponse(
  userMessage: string,
  goals: UserGoal[],
  recentMetrics: DailyMetrics | null,
  chatHistory: Array<{ role: string; message: string }>,
  mode?: string
): string {
  const message = userMessage.toLowerCase();

  if (mode === 'psychiatry_talk') {
    return generatePsychiatryCounselingResponse(message);
  }

  if (mode === 'psychiatry_diagnostic') {
    return generatePsychiatryDiagnosticResponse(message, chatHistory);
  }

  const metricsContext = recentMetrics
    ? `Your recent metrics show: Mood ${recentMetrics.mood_score_1_10}/10, Energy ${recentMetrics.energy_level_1_10}/10, Sleep ${recentMetrics.sleep_quality_1_10}/10.`
    : '';

  if (message.includes('goal') || message.includes('target') || message.includes('achieve')) {
    if (goals.length === 0) {
      return "Setting clear goals is crucial for biohacking success. What would you like to achieve? Consider health, mental, or productivity goals.";
    }
    return `I'm here to help you achieve your goals. Which specific area would you like to focus on, or would you like to discuss a new goal?`;
  }

  if (message.includes('stress') || message.includes('anxious') || message.includes('overwhelm')) {
    return `Let's address your stress. I recommend: 1) Deep breathing (4-7-8 technique), 2) A 10-minute walk outside, 3) Journaling your thoughts, 4) Progressive muscle relaxation. ${metricsContext} Which of these resonates with you?`;
  }

  if (message.includes('sleep') || message.includes('tired') || message.includes('energy')) {
    return `Sleep and energy optimization are key. ${metricsContext} Try: 1) No screens 1 hour before bed, 2) Keep room at 65-68°F, 3) Magnesium supplement 1 hour before sleep, 4) 20-minute power nap if needed during day, 5) Morning sunlight exposure within 30 minutes of waking.`;
  }

  if (message.includes('diet') || message.includes('nutrition') || message.includes('food') || message.includes('eat')) {
    return `Nutrition is fundamental to biohacking. ${metricsContext} Focus on: 1) Protein first (30g at breakfast), 2) Colorful vegetables at every meal, 3) Healthy fats (avocado, nuts, olive oil), 4) Minimize processed foods and added sugar, 5) Stay hydrated (half your body weight in ounces of water daily).`;
  }

  if (message.includes('exercise') || message.includes('workout') || message.includes('fitness')) {
    return `Movement is medicine. ${metricsContext} Optimal approach: 1) Strength training 3x/week (compound movements), 2) Zone 2 cardio (conversational pace) 150min/week, 3) Daily walking 7-10k steps, 4) Mobility work 10min daily, 5) At least one full rest day per week.`;
  }

  if (message.includes('focus') || message.includes('concentration') || message.includes('productive')) {
    return `Let's optimize your cognitive performance. ${metricsContext} Try: 1) 90-minute deep work blocks with 20-minute breaks, 2) Eliminate distractions (phone in another room), 3) Cold exposure before work, 4) Optimize lighting (bright blue light during work), 5) Background music or white noise for sustained attention.`;
  }

  if (message.includes('supplement') || message.includes('vitamin')) {
    return `Key supplements to consider: 1) Vitamin D3 (2000-5000 IU), 2) Omega-3 (2g EPA/DHA), 3) Magnesium glycinate (400mg), 4) Creatine monohydrate (5g), 5) Quality multivitamin. ${metricsContext} Always consult a healthcare provider first.`;
  }

  if (message.includes('morning') || message.includes('routine') || message.includes('start')) {
    return `An optimal morning routine: 1) Hydrate immediately (16oz water with a pinch of salt), 2) Sunlight exposure within 30 min of waking, 3) Light movement or stretching, 4) Protein-rich breakfast (30g+), 5) Cold shower for alertness. ${metricsContext}`;
  }

  if (message.includes('track') || message.includes('measure') || message.includes('data')) {
    return `You're on the right track with measurement! ${metricsContext} What you measure improves. Focus on trends over time, not daily fluctuations. Key metrics to track: sleep quality, energy levels, mood, exercise, nutrition, and cognitive performance. Which metric would you like to optimize?`;
  }

  if (message.includes('motivat') || message.includes('inspire')) {
    return `Remember: Small consistent actions compound into extraordinary results. You're not competing with others - you're becoming the best version of yourself. ${metricsContext} What's one micro-habit you can implement today to move closer to your ideal self?`;
  }

  if (message.includes('hello') || message.includes('hi ') || message.includes('hey')) {
    return `Hello! I'm your AI biohacking coach. ${metricsContext} I'm here to help you optimize your mind and body through evidence-based strategies. What would you like to work on today?`;
  }

  if (message.includes('help') || message.includes('what can you')) {
    return `I can help you with: nutrition optimization, sleep enhancement, stress management, exercise programming, cognitive performance, supplement guidance, habit formation, and achieving your goals. ${metricsContext} What area interests you most?`;
  }

  return `That's an interesting question. ${metricsContext} Let me provide some guidance: prioritize quality sleep (7-9 hours), maintain consistent meal timing, move regularly throughout the day, practice stress management, and stay hydrated. What specific aspect of optimization would you like to explore further?`;
}

function generatePsychiatryCounselingResponse(message: string): string {
  if (message.includes('hello') || message.includes('hi ') || message.includes('hey')) {
    return "Hello, I'm here to listen and support you. This is a safe, non-judgmental space where you can share whatever is on your mind. How are you feeling today?";
  }

  if (message.includes('anxious') || message.includes('anxiety') || message.includes('worried') || message.includes('nervous')) {
    return "Thank you for sharing that you're feeling anxious. Those feelings are valid and it's important that you're acknowledging them. Anxiety can be overwhelming. Can you tell me more about what's been triggering these feelings? When do you notice the anxiety most intensely?";
  }

  if (message.includes('depress') || message.includes('sad') || message.includes('down') || message.includes('hopeless')) {
    return "I hear that you're going through a really difficult time. Feelings of sadness and depression can feel all-consuming. It's important to know that you're not alone in this, and these feelings, while painful, are something we can work through together. What's been weighing most heavily on your mind?";
  }

  if (message.includes('stress') || message.includes('overwhelm') || message.includes('too much') || message.includes('cant cope')) {
    return "It sounds like you're carrying a lot right now, and feeling overwhelmed is a natural response to that. Let's take this one step at a time. What feels most pressing or difficult for you at this moment? Sometimes breaking things down can help us see a path forward.";
  }

  if (message.includes('sleep') || message.includes('insomnia') || message.includes('tired') || message.includes('exhausted')) {
    return "Sleep difficulties can really affect how we feel and function. I'm glad you brought this up. Can you tell me more about your sleep patterns? When did this start, and have you noticed what might be interfering with your rest?";
  }

  if (message.includes('relationship') || message.includes('partner') || message.includes('friend') || message.includes('family')) {
    return "Relationships can be a significant source of both joy and stress. I appreciate you sharing this with me. Can you tell me more about what's happening in your relationships? What's been most challenging for you?";
  }

  if (message.includes('angry') || message.includes('mad') || message.includes('frustrated') || message.includes('irritated')) {
    return "Anger is a valid emotion, and it's often telling us that something important needs attention. Thank you for being honest about how you're feeling. Can you help me understand what's been frustrating you? What situations or thoughts trigger these feelings?";
  }

  if (message.includes('lonely') || message.includes('isolated') || message.includes('alone')) {
    return "Loneliness can be one of the most painful experiences we face. I want you to know that your feelings matter, and reaching out like this shows real courage. Can you tell me more about your experience with loneliness? What's been missing in your life?";
  }

  if (message.includes('trauma') || message.includes('abuse') || message.includes('hurt') || message.includes('pain')) {
    return "Thank you for trusting me with something so difficult. Processing trauma and pain takes tremendous courage. While I'm here to support you, experiences like these often benefit from specialized professional care. Can you tell me a bit more about what you're comfortable sharing? And please know that seeking help from a trauma-informed therapist could be really valuable.";
  }

  if (message.includes('suicid') || message.includes('kill myself') || message.includes('end it') || message.includes('not worth living')) {
    return "I'm very concerned about what you're sharing. Your life has value, and these feelings, while overwhelming right now, can change with proper support. Please reach out to a crisis helpline immediately:\n\n**National Suicide Prevention Lifeline**: 988 (US)\n**Crisis Text Line**: Text HOME to 741741\n**International Association for Suicide Prevention**: https://www.iasp.info/resources/Crisis_Centres/\n\nPlease don't face this alone. Will you reach out to one of these resources right now?";
  }

  if (message.includes('better') || message.includes('improve') || message.includes('help') || message.includes('cope')) {
    return "It's really positive that you're looking for ways to feel better and develop coping strategies. That shows resilience and self-awareness. Everyone's path is different, but some approaches that often help include: building a support network, developing self-care routines, and learning emotional regulation skills. What areas feel most important to you right now?";
  }

  if (message.includes('thank') || message.includes('appreciate')) {
    return "You're very welcome. I'm here to support you, and I appreciate you opening up and sharing with me. How are you feeling about our conversation? Is there anything else on your mind?";
  }

  return "I'm listening, and I want to understand what you're experiencing. Your feelings and experiences are important. Can you tell me more about what's on your mind? What would be most helpful for us to explore together?";
}

function generatePsychiatryDiagnosticResponse(message: string, chatHistory: Array<{ role: string; message: string }>): string {
  const sessionLength = chatHistory.filter(m => m.role === 'user').length;

  if (message.includes('hello') || message.includes('hi ') || sessionLength === 0) {
    return "Hello, I'm here to help you organize information about your symptoms that you can share with your healthcare provider. This assessment follows DSM-5 criteria and will ask structured questions about your mental health symptoms. Let's begin:\n\nWhat are the main concerns or symptoms that brought you here today?";
  }

  if (sessionLength === 1) {
    return "Thank you for sharing that. To help me understand better, I'd like to ask some specific questions:\n\n1. How long have you been experiencing these symptoms?\n2. When did you first notice them?\n3. Have they been present consistently or do they come and go?";
  }

  if (sessionLength === 2) {
    return "I appreciate you providing that context. Now let's explore the impact:\n\n1. How are these symptoms affecting your daily life? (Work, relationships, self-care)\n2. On a scale of 1-10, how much distress do these symptoms cause you?\n3. Have you noticed any triggers that make the symptoms worse?";
  }

  if (sessionLength === 3) {
    return "Let me ask about some specific symptom areas:\n\n**Mood**: How has your mood been lately? Any persistent sadness, emptiness, or mood swings?\n\n**Anxiety**: Do you experience excessive worry, panic attacks, or avoidance behaviors?\n\n**Sleep**: How is your sleep? Any difficulty falling asleep, staying asleep, or sleeping too much?";
  }

  if (sessionLength === 4) {
    return "Thank you. Let's continue with more symptom areas:\n\n**Appetite/Weight**: Any changes in appetite or weight (gain or loss)?\n\n**Energy**: How are your energy levels? Fatigue, restlessness, or agitation?\n\n**Concentration**: Any difficulty focusing, making decisions, or memory problems?";
  }

  if (sessionLength === 5) {
    return "We're making good progress. A few more areas:\n\n**Social Functioning**: How are your relationships and social interactions? Any withdrawal or conflicts?\n\n**Work/School**: How is your performance at work or school? Any difficulties completing tasks?\n\n**Physical Symptoms**: Any unexplained physical symptoms like headaches, stomach issues, or pain?";
  }

  if (sessionLength === 6) {
    return "Important safety questions:\n\n**Self-Harm**: Have you had any thoughts of hurting yourself?\n\n**Suicide**: Have you had thoughts about ending your life? If yes, do you have a plan?\n\n**Harm to Others**: Have you had thoughts about hurting anyone else?\n\nPlease answer honestly - this information is crucial for getting you appropriate help.";
  }

  if (message.includes('yes') && (message.includes('suicid') || message.includes('hurt') || message.includes('harm'))) {
    return "**IMMEDIATE ACTION NEEDED**\n\nBased on what you've shared, please reach out to crisis support immediately:\n\n**National Suicide Prevention Lifeline**: 988 (US)\n**Crisis Text Line**: Text HOME to 741741\n**Emergency Services**: 911 (US) or your local emergency number\n\nYou can also go to your nearest emergency room. Please don't wait - reach out for help right now.";
  }

  if (sessionLength >= 7) {
    return "Thank you for providing this comprehensive information. Based on our conversation, here's a summary you can share with your healthcare provider:\n\n**Chief Complaints**: [The symptoms you described]\n**Duration**: [How long you've experienced them]\n**Impact**: Affecting daily functioning in work/school, relationships, and self-care\n**Symptom Pattern**: [Consistent/Intermittent]\n\n**Next Steps I Recommend**:\n1. Schedule an appointment with a psychiatrist or licensed mental health professional as soon as possible\n2. Bring this conversation summary with you\n3. Be honest with your provider about all symptoms\n4. Ask about treatment options including therapy and/or medication\n5. If symptoms worsen, seek immediate care\n\nRemember: This is not a diagnosis. Only a licensed healthcare provider can diagnose and treat mental health conditions. Is there anything else you'd like to add to share with your provider?";
  }

  return "I see. Can you elaborate on that a bit more? Specifically:\n\n- How often does this occur?\n- How severe is it when it happens?\n- What makes it better or worse?\n- How does it impact your daily life?";
}
