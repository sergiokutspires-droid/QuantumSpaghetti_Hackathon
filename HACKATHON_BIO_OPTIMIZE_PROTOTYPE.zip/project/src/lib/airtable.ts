export type AirtableWeeklyStep = {
  id: string;
  week: number;
  goal: string;
  goalId?: string;
  goalTitle?: string;
};

export type AirtableGoalRoadmap = {
  goalId: string;
  goalTitle: string;
  weeks: AirtableWeeklyStep[];
};

const AIRTABLE_CONFIG = {
  baseId: 'appaYblbQ3dObzWvT',
  tableIdOrName: 'tblIfOBzzbY2ugOr3',
  apiKey: 'patoQtjKJEdnCfgI7.bffdc01beb04c9ba56322044d83de66ef1dfcd88112ec0981178dcbcbb54d863',
};

export async function fetchGoalRoadmap(goalTitle: string): Promise<AirtableWeeklyStep[]> {
  const { baseId, tableIdOrName, apiKey } = AIRTABLE_CONFIG;

  if (!baseId || !apiKey) {
    console.log('Airtable not configured, using fallback');
    return generateFallbackRoadmap(goalTitle);
  }

  try {
    const filterFormula = `SEARCH("${goalTitle.replace(/"/g, '\\"')}", {Goal})`;
    const url = `https://api.airtable.com/v0/${baseId}/${tableIdOrName}?filterByFormula=${encodeURIComponent(filterFormula)}`;

    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
    });

    if (!response.ok) {
      console.error('Airtable API error:', response.status);
      return generateFallbackRoadmap(goalTitle);
    }

    const data = await response.json();

    if (!data.records || data.records.length === 0) {
      console.log('No records found, using fallback');
      return generateFallbackRoadmap(goalTitle);
    }

    const record = data.records[0];
    const fields = record.fields;

    const weeks: AirtableWeeklyStep[] = [];

    for (let i = 1; i <= 4; i++) {
      const weekGoal = fields[`Goal WEEK${i}`];
      if (weekGoal) {
        weeks.push({
          id: `week${i}`,
          week: i,
          goal: weekGoal,
          goalTitle: fields.Goal || goalTitle,
        });
      }
    }

    if (weeks.length === 0) {
      return generateFallbackRoadmap(goalTitle);
    }

    return weeks;
  } catch (error) {
    console.error('Error fetching from Airtable:', error);
    return generateFallbackRoadmap(goalTitle);
  }
}

export async function fetchUserRoadmapByName(userName: string): Promise<{ goal: string; weeks: AirtableWeeklyStep[] } | null> {
  const { baseId, tableIdOrName, apiKey } = AIRTABLE_CONFIG;

  if (!baseId || !apiKey) {
    return null;
  }

  try {
    const filterFormula = `{Name}="${userName.replace(/"/g, '\\"')}"`;
    const url = `https://api.airtable.com/v0/${baseId}/${tableIdOrName}?filterByFormula=${encodeURIComponent(filterFormula)}`;

    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
    });

    if (!response.ok) {
      console.error('Airtable API error:', response.status);
      return null;
    }

    const data = await response.json();

    if (!data.records || data.records.length === 0) {
      return null;
    }

    const record = data.records[0];
    const fields = record.fields;

    const weeks: AirtableWeeklyStep[] = [];
    const mainGoal = fields.Goal || '';

    for (let i = 1; i <= 4; i++) {
      const weekGoal = fields[`Goal WEEK${i}`];
      if (weekGoal) {
        weeks.push({
          id: `week${i}`,
          week: i,
          goal: weekGoal,
          goalTitle: mainGoal,
        });
      }
    }

    return {
      goal: mainGoal,
      weeks,
    };
  } catch (error) {
    console.error('Error fetching user roadmap from Airtable:', error);
    return null;
  }
}

export async function syncGoalToAirtable(goalId: string, goalTitle: string, goalDescription: string): Promise<void> {
  const n8nUrl = import.meta.env.VITE_N8N_GOAL_SYNC_URL;

  if (!n8nUrl || n8nUrl === 'https://your-n8n-instance.com/webhook/sync-goal') {
    console.log('n8n sync URL not configured, skipping sync');
    return;
  }

  try {
    await fetch(n8nUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        goalId,
        goalTitle,
        goalDescription,
        action: 'create_roadmap',
      }),
    });
  } catch (error) {
    console.error('Error syncing to n8n/Airtable:', error);
  }
}

function generateFallbackRoadmap(goalTitle: string): AirtableWeeklyStep[] {
  return [
    {
      id: 'week1',
      week: 1,
      goal: 'Foundation & Assessment - Establish your baseline and create initial habits',
      goalTitle,
    },
    {
      id: 'week2',
      week: 2,
      goal: 'Building Momentum - Increase consistency and refine your approach',
      goalTitle,
    },
    {
      id: 'week3',
      week: 3,
      goal: 'Optimization & Growth - Enhance your strategy and push boundaries',
      goalTitle,
    },
    {
      id: 'week4',
      week: 4,
      goal: 'Mastery & Planning Ahead - Solidify habits and plan next phase',
      goalTitle,
    },
  ];
}
