import { StatusType } from '../lib/airtableFieldMapping';

export interface AirtableRecord {
  id: string;
  fields: AirtableFields;
  createdTime: string;
}

export interface AirtableFields {
  Goal?: string;
  Goal_Description?: string;
  Week_1?: string;
  Week_2?: string;
  Week_3?: string;
  Week_4?: string;
  Status?: StatusType;
  Progress?: number;
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  week1: string;
  week2: string;
  week3: string;
  week4: string;
  status: StatusType;
  progress: number;
  createdTime: string;
  lastModified: string;
}

export interface AirtableListResponse {
  records: AirtableRecord[];
  offset?: string;
}

export interface AirtableUpdatePayload {
  fields: Partial<AirtableFields>;
}

export interface CachedData {
  goals: Goal[];
  lastSyncedAt: string;
}
