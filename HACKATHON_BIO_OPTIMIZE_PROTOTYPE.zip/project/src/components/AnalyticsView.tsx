import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { Download, BarChart3, RefreshCw } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function AnalyticsView() {
  const { user } = useAuth();
  const [exporting, setExporting] = useState(false);

  const exportToCSV = async () => {
    if (!user) return;
    setExporting(true);

    try {
      const { data: metrics } = await supabase
        .from('daily_metrics')
        .select('*')
        .eq('user_id', user.id)
        .order('date', { ascending: false });

      if (!metrics || metrics.length === 0) {
        alert('No data to export yet. Start tracking your daily metrics!');
        setExporting(false);
        return;
      }

      const headers = [
        'date',
        'meditation_time_minutes',
        'journaling_time_minutes',
        'stress_level_1_10',
        'mood_score_1_10',
        'sleep_quality_1_10',
        'water_intake_liters',
        'steps_per_day',
        'exercise_minutes',
        'resting_heart_rate_bpm',
        'weight_kg',
        'energy_level_1_10',
        'meals_eaten',
        'protein_intake_grams',
        'fruit_vegetable_servings',
        'sugar_alcohol_consumption',
        'deep_work_hours',
        'reading_time_minutes',
        'study_time_minutes',
      ];

      const csvRows = [headers.join(',')];

      metrics.forEach((row) => {
        const values = headers.map((header) => {
          const value = row[header];
          return typeof value === 'string' ? `"${value}"` : value;
        });
        csvRows.push(values.join(','));
      });

      const csvContent = csvRows.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `biohacking-metrics-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting CSV:', error);
      alert('Failed to export data. Please try again.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="h-full bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex flex-col">
      <div className="bg-gradient-to-r from-slate-900/90 to-slate-800/90 border-b border-slate-700/50 p-8 backdrop-blur-sm">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-2">
              Analytics Dashboard
            </h2>
            <p className="text-slate-400">Visualize your biohacking data and export metrics</p>
          </div>
          <button
            onClick={exportToCSV}
            disabled={exporting}
            className="flex items-center space-x-2 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 disabled:from-slate-600 disabled:to-slate-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-green-500/30 hover:shadow-green-500/50"
          >
            {exporting ? <RefreshCw className="animate-spin" size={20} /> : <Download size={20} />}
            <span>{exporting ? 'Exporting...' : 'Export CSV'}</span>
          </button>
        </div>
      </div>

      <div className="flex-1 p-8">
        <div className="h-full bg-slate-800/50 rounded-2xl overflow-hidden border border-slate-700/50 shadow-xl">
          <img
            src="/analytics/analytics-dashboard.jpg"
            alt="Analytics Dashboard Preview"
            className="w-full h-full object-contain"
          />
        </div>
      </div>
    </div>
  );
}
