import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Sidebar } from './Sidebar';
import { StatsPanel } from './StatsPanel';
import { ChatInterface } from './ChatInterface';
import { MindsetView } from './MindsetView';
import { PsychiatryView } from './PsychiatryView';
import { TrackingView } from './TrackingView';
import { AnalyticsView } from './AnalyticsView';
import { RoadmapView } from './RoadmapView';
import { GoalsView } from './GoalsView';
import { EnlightenmentView } from './EnlightenmentView';

export function Dashboard() {
  const { user, signOut } = useAuth();
  const [currentView, setCurrentView] = useState('enlightenment');

  if (!user) return null;

  const renderView = () => {
    switch (currentView) {
      case 'enlightenment':
        return <EnlightenmentView userId={user.id} />;
      case 'airtable-goals':
        return <GoalsView userId={user.id} />;
      case 'roadmap':
        return <RoadmapView userId={user.id} />;
      case 'biohacking':
        return (
          <ChatInterface
            userId={user.id}
            mode="biohacking"
            title="AI Biohacking Chat"
            description="Personalized lifestyle optimization and performance enhancement"
          />
        );
      case 'mindset':
        return <MindsetView userId={user.id} />;
      case 'psychiatry':
        return <PsychiatryView userId={user.id} />;
      case 'tracking':
        return <TrackingView userId={user.id} />;
      case 'analytics':
        return <AnalyticsView />;
      default:
        return null;
    }
  };

  const showStatsPanel = currentView !== 'roadmap' && currentView !== 'analytics' && currentView !== 'airtable-goals' && currentView !== 'enlightenment' && currentView !== 'biohacking';

  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} onSignOut={signOut} />
      <div className="flex-1 overflow-hidden">{renderView()}</div>
      {showStatsPanel && <StatsPanel userId={user.id} />}
    </div>
  );
}
