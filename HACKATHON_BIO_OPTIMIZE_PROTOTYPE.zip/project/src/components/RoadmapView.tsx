import { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';

type RoadmapViewProps = {
  userId: string;
};

const AIRTABLE_CONFIG = {
  baseId: 'appaYblbQ3dObzWvT',
  tableIdOrName: 'tblIfOBzzbY2ugOr3',
  apiKey: 'patoQtjKJEdnCfgI7.bffdc01beb04c9ba56322044d83de66ef1dfcd88112ec0981178dcbcbb54d863',
  userName: 'John',
};

const DEMO_DATA = {
  Name: 'John',
  Goal: 'Lose twenty kilograms',
  'Goal WEEK1': 'Commit to a daily step target of 10,000 steps and track your progress',
  'Goal WEEK2': 'Establish a consistent meal prep routine for healthier eating habits',
  'Goal WEEK3': 'Add 3 strength training sessions per week to build muscle',
  'Goal WEEK4': 'Create a sleep schedule aiming for 7-8 hours per night'
};

export function RoadmapView({ userId }: RoadmapViewProps) {
  const [mainGoal, setMainGoal] = useState<string>('');
  const [weeklyGoals, setWeeklyGoals] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentDate, setCurrentDate] = useState('');
  const [showEmpty, setShowEmpty] = useState(false);

  useEffect(() => {
    loadProgressionMap();
    updateDate();
  }, []);

  const updateDate = () => {
    const now = new Date();
    const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' };
    setCurrentDate(now.toLocaleDateString('en-US', options).toUpperCase());
  };

  const loadProgressionMap = async () => {
    setLoading(true);
    setShowEmpty(false);

    try {
      const data = await fetchAirtableData();

      if (data) {
        setMainGoal(data.Goal || 'No goal defined');

        const performanceGoals = [
          data['Goal WEEK1'],
          data['Goal WEEK2'],
          data['Goal WEEK3'],
          data['Goal WEEK4']
        ].filter(goal => goal && goal.trim() !== '');

        setWeeklyGoals(performanceGoals);
      } else {
        setShowEmpty(true);
      }
    } catch (error) {
      console.error('Error loading progression map:', error);
      setShowEmpty(true);
    } finally {
      setLoading(false);
    }
  };

  const fetchAirtableData = async () => {
    const { baseId, tableIdOrName, apiKey, userName } = AIRTABLE_CONFIG;

    await new Promise(resolve => setTimeout(resolve, 500));

    if (!apiKey || !baseId || !tableIdOrName) {
      console.warn('Airtable configuration is incomplete, using demo data');
      return DEMO_DATA;
    }

    try {
      const filterFormula = `{Name}="${userName.replace(/"/g, '\\"')}"`;
      const url = `https://api.airtable.com/v0/${baseId}/${tableIdOrName}?filterByFormula=${encodeURIComponent(filterFormula)}`;

      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${apiKey}`
        }
      });

      if (!response.ok) {
        console.error('Airtable request failed:', response.status);
        return DEMO_DATA;
      }

      const result = await response.json();

      const record = result.records.find((r: any) =>
        r.fields.Name && r.fields.Name.toLowerCase() === userName.toLowerCase()
      );

      return record ? record.fields : DEMO_DATA;
    } catch (error) {
      console.error('Airtable fetch error:', error);
      console.log('Falling back to demo data');
      return DEMO_DATA;
    }
  };

  const getGradientForStep = (index: number) => {
    const gradients = [
      'from-cyan-400 to-blue-500',
      'from-blue-500 to-purple-600',
      'from-purple-600 to-pink-500',
      'from-pink-500 to-red-500',
      'from-red-500 to-orange-500'
    ];
    return gradients[index % gradients.length];
  };

  const getBoxShadowForStep = (index: number) => {
    const shadows = [
      'shadow-[0_4px_15px_rgba(34,211,238,0.4)]',
      'shadow-[0_4px_15px_rgba(124,58,237,0.4)]',
      'shadow-[0_4px_15px_rgba(168,85,247,0.4)]',
      'shadow-[0_4px_15px_rgba(236,72,153,0.4)]',
      'shadow-[0_4px_15px_rgba(239,68,68,0.4)]'
    ];
    return shadows[index % shadows.length];
  };

  return (
    <div className="h-full relative overflow-hidden bg-gradient-to-br from-[#0a1628] via-[#0d1b2a] to-[#0a1520]">
      <style>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.5); }
        }
        @keyframes float {
          0%, 100% { transform: translate(0, 0) rotate(0deg); }
          33% { transform: translate(30px, -30px) rotate(120deg); }
          66% { transform: translate(-20px, 20px) rotate(240deg); }
        }
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes fadeIn {
          to { opacity: 1; }
        }
        .star {
          position: absolute;
          width: 2px;
          height: 2px;
          background: rgba(255, 255, 255, 0.8);
          border-radius: 50%;
          animation: twinkle 4s infinite ease-in-out;
        }
        .gradient-orb {
          position: fixed;
          border-radius: 50%;
          filter: blur(80px);
          opacity: 0.15;
          pointer-events: none;
          animation: float 20s infinite ease-in-out;
        }
        .orb1 {
          width: 400px;
          height: 400px;
          background: linear-gradient(135deg, #4ecdc4, #44a08d);
          top: -100px;
          right: -100px;
        }
        .orb2 {
          width: 300px;
          height: 300px;
          background: linear-gradient(135deg, #667eea, #764ba2);
          bottom: -50px;
          left: -50px;
          animation-delay: -10s;
        }
        .orb3 {
          width: 350px;
          height: 350px;
          background: linear-gradient(135deg, #f093fb, #f5576c);
          top: 50%;
          right: -100px;
          animation-delay: -5s;
        }
        .fade-in {
          opacity: 0;
          animation: fadeIn 0.6s ease forwards;
        }
        .slide-in-left {
          animation: slideInLeft 0.5s ease forwards;
          opacity: 0;
        }
      `}</style>

      <div className="fixed inset-0 pointer-events-none z-0">
        {[...Array(100)].map((_, i) => (
          <div
            key={i}
            className="star"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 4}s`
            }}
          />
        ))}
      </div>

      <div className="gradient-orb orb1" />
      <div className="gradient-orb orb2" />
      <div className="gradient-orb orb3" />

      <div className="fixed top-0 left-0 right-0 p-5 md:px-8 flex justify-between items-center z-50 bg-gradient-to-b from-[rgba(10,22,40,0.9)] to-transparent backdrop-blur-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">BioOptimize</span>
        </div>
        <div className="text-xs text-slate-400 uppercase tracking-widest">
          {currentDate}
        </div>
      </div>

      <div className="relative z-10 max-w-2xl mx-auto px-6 md:px-8 py-20 md:py-24 h-full overflow-y-auto">
        <div className="text-center mb-10 fade-in">
          <h1 className="text-4xl md:text-5xl font-light mb-2 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Your Roadmap
          </h1>
          <p className="text-sm text-slate-500">Your journey to enlightenment</p>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="w-12 h-12 animate-spin text-cyan-400" />
          </div>
        ) : showEmpty ? (
          <div className="text-center py-20 fade-in">
            <div className="text-6xl mb-6 opacity-50">🗺️</div>
            <div className="text-2xl font-semibold text-slate-400 mb-3">
              No Roadmap Found
            </div>
            <div className="text-sm text-slate-500 leading-relaxed max-w-md mx-auto">
              No roadmap found for <strong>{AIRTABLE_CONFIG.userName}</strong>.<br />
              Please check your configuration.
            </div>
          </div>
        ) : (
          <div className="fade-in">
            <div className="relative bg-white/5 backdrop-blur-xl border border-purple-500/30 rounded-3xl p-8 md:p-10 mb-10 overflow-hidden shadow-[0_8px_32px_rgba(102,126,234,0.15)]">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent animate-[shimmer_3s_infinite]" />
              </div>

              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-purple-400 mb-3 font-semibold">
                <span>🎯</span>
                <span>Main Goal</span>
              </div>

              <div className="text-2xl md:text-3xl font-light leading-relaxed bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
                {mainGoal}
              </div>
            </div>

            {weeklyGoals.length > 0 ? (
              <div className="relative">
                <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-400/50 via-purple-500/50 to-pink-500/50" />

                <div className="space-y-5">
                  {weeklyGoals.map((goal, index) => (
                    <div
                      key={index}
                      className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 md:p-6 pl-16 md:pl-20 hover:bg-white/8 hover:border-cyan-400/30 transition-all duration-300 hover:translate-x-2 slide-in-left"
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      <div className={`absolute left-3 md:left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-gradient-to-br ${getGradientForStep(index)} flex items-center justify-center text-white font-semibold text-base ${getBoxShadowForStep(index)} z-10`}>
                        W{index + 1}
                      </div>

                      <div className="text-sm md:text-base text-slate-200 leading-relaxed">
                        {goal}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-16 fade-in">
                <div className="text-5xl mb-4 opacity-50">🗺️</div>
                <div className="text-lg font-medium text-slate-400 mb-2">
                  No performance goals defined yet.
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
