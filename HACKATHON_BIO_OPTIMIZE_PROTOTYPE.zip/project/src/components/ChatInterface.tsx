import { useState, useEffect, useRef } from 'react';
import { Send, Loader2, RotateCcw, Sparkles } from 'lucide-react';
import { supabase, ChatMessage as ChatMessageType, UserGoal, DailyMetrics } from '../lib/supabase';
import { generateFallbackResponse } from '../lib/fallbackAI';
import { ChatMessage } from './ChatMessage';

type ChatInterfaceProps = {
  userId: string;
  mode: string;
  title: string;
  description: string;
  systemPrompt?: string;
};

export function ChatInterface({ userId, mode, title, description, systemPrompt }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [goals, setGoals] = useState<UserGoal[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    loadChatHistory();
    loadGoals();
  }, [userId, mode]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [input]);

  const loadGoals = async () => {
    const { data } = await supabase
      .from('user_goals')
      .select('*')
      .eq('user_id', userId)
      .eq('status', 'active');

    if (data) setGoals(data);
  };

  const loadChatHistory = async () => {
    const { data } = await supabase
      .from('chat_history')
      .select('*')
      .eq('user_id', userId)
      .eq('mode', mode)
      .order('created_at', { ascending: true })
      .limit(50);

    if (data) setMessages(data);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const clearChat = async () => {
    if (confirm('Are you sure you want to clear this conversation?')) {
      await supabase
        .from('chat_history')
        .delete()
        .eq('user_id', userId)
        .eq('mode', mode);

      setMessages([]);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setLoading(true);

    const userMsg: ChatMessageType = {
      id: crypto.randomUUID(),
      user_id: userId,
      mode,
      message: userMessage,
      role: 'user',
      created_at: new Date().toISOString(),
    };

    await supabase.from('chat_history').insert({
      user_id: userId,
      mode,
      message: userMessage,
      role: 'user',
    });

    setMessages((prev) => [...prev, userMsg]);

    const today = new Date().toISOString().split('T')[0];
    const { data: metrics } = await supabase
      .from('daily_metrics')
      .select('*')
      .eq('user_id', userId)
      .eq('date', today)
      .maybeSingle();

    let assistantMessage = '';

    try {
      const n8nUrl = import.meta.env.VITE_N8N_WEBHOOK_URL;

      if (n8nUrl && n8nUrl !== 'https://your-n8n-instance.com/webhook/chat') {
        const conversationContext = messages.slice(-10).map(m => ({
          role: m.role,
          content: m.message
        }));

        const requestBody: any = {
          userId,
          mode,
          message: userMessage,
          conversation: conversationContext,
          metrics,
        };

        if (mode !== 'psychiatry_talk' && mode !== 'psychiatry_diagnostic') {
          requestBody.goals = goals.map(g => ({ title: g.title, description: g.description }));
        }

        if (systemPrompt) {
          requestBody.system_prompt = systemPrompt;
        }

        const response = await fetch(n8nUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody),
        });

        const data = await response.json();
        assistantMessage = data.response || generateFallbackResponse(userMessage, goals, metrics, messages, mode);
      } else {
        assistantMessage = generateFallbackResponse(userMessage, goals, metrics, messages, mode);
      }
    } catch (error) {
      assistantMessage = generateFallbackResponse(userMessage, goals, metrics, messages, mode);
    }

    await supabase.from('chat_history').insert({
      user_id: userId,
      mode,
      message: assistantMessage,
      role: 'assistant',
    });

    setMessages((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        user_id: userId,
        mode,
        message: assistantMessage,
        role: 'assistant',
        created_at: new Date().toISOString(),
      },
    ]);

    setLoading(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(e);
    }
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-slate-950 to-slate-900">
      <div className="flex-shrink-0 bg-gradient-to-r from-slate-900/95 to-slate-800/95 backdrop-blur-xl border-b border-slate-700/50 px-8 py-6 shadow-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Sparkles size={24} className="text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{title}</h2>
              <p className="text-slate-400 text-sm mt-0.5">{description}</p>
            </div>
          </div>
          {messages.length > 0 && (
            <button
              onClick={clearChat}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800/50 hover:bg-slate-700/50 text-slate-300 hover:text-white rounded-xl transition-all duration-200 border border-slate-700/50 hover:border-slate-600"
            >
              <RotateCcw size={16} />
              <span className="text-sm font-medium">Clear</span>
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center p-8">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-2xl flex items-center justify-center mb-6">
              <Sparkles size={36} className="text-blue-400" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">Start a Conversation</h3>
            <p className="text-slate-400 text-center max-w-md mb-8">
              Ask me anything about {mode === 'biohacking' ? 'optimization, health, or performance' : mode === 'stoic' || mode === 'motivational' ? 'mindset and personal development' : mode === 'psychiatry_talk' || mode === 'psychiatry_diagnostic' ? 'your mental health and well-being' : 'mental health and well-being'}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-2xl">
              {mode === 'biohacking' && (
                <>
                  <SuggestedPrompt onClick={setInput} text="How can I improve my sleep quality?" />
                  <SuggestedPrompt onClick={setInput} text="What's the best morning routine?" />
                  <SuggestedPrompt onClick={setInput} text="How do I optimize my energy levels?" />
                  <SuggestedPrompt onClick={setInput} text="What supplements should I consider?" />
                </>
              )}
              {(mode === 'stoic' || mode === 'motivational') && (
                <>
                  <SuggestedPrompt onClick={setInput} text="How do I stay motivated daily?" />
                  <SuggestedPrompt onClick={setInput} text="Help me overcome procrastination" />
                  <SuggestedPrompt onClick={setInput} text="How to handle setbacks?" />
                  <SuggestedPrompt onClick={setInput} text="Build better habits" />
                </>
              )}
              {mode === 'psychiatry_talk' && (
                <>
                  <SuggestedPrompt onClick={setInput} text="I've been feeling really anxious lately" />
                  <SuggestedPrompt onClick={setInput} text="I'm struggling with stress and overwhelm" />
                  <SuggestedPrompt onClick={setInput} text="I feel lonely and isolated" />
                  <SuggestedPrompt onClick={setInput} text="I'm having trouble sleeping" />
                </>
              )}
              {mode === 'psychiatry_diagnostic' && (
                <>
                  <SuggestedPrompt onClick={setInput} text="I want to assess my symptoms" />
                  <SuggestedPrompt onClick={setInput} text="I've been feeling down for weeks" />
                  <SuggestedPrompt onClick={setInput} text="My anxiety is affecting daily life" />
                  <SuggestedPrompt onClick={setInput} text="I need help organizing my symptoms" />
                </>
              )}
            </div>
          </div>
        )}

        <div className="max-w-4xl mx-auto">
          {messages.map((message) => (
            <ChatMessage
              key={message.id}
              message={message.message}
              role={message.role}
              timestamp={message.created_at}
            />
          ))}

          {loading && (
            <div className="flex gap-4 px-4 py-6 bg-slate-800/30">
              <div className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center shadow-lg bg-gradient-to-br from-slate-700 to-slate-600">
                <Loader2 size={20} className="text-white animate-spin" />
              </div>
              <div className="flex-1 pt-1">
                <div className="font-semibold text-white text-sm mb-2">AI Assistant</div>
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="flex-shrink-0 border-t border-slate-800/50 bg-slate-900/50 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto p-6">
          <form onSubmit={sendMessage} className="relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Message AI Assistant..."
              disabled={loading}
              rows={1}
              className="w-full bg-slate-800/50 border border-slate-700/50 rounded-2xl px-6 py-4 pr-14 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50 resize-none max-h-40 transition-all duration-200"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="absolute right-3 bottom-3 w-10 h-10 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 disabled:from-slate-700 disabled:to-slate-700 text-white rounded-xl transition-all duration-200 flex items-center justify-center shadow-lg disabled:shadow-none hover:scale-105 disabled:scale-100"
            >
              <Send size={18} />
            </button>
          </form>
          <p className="text-xs text-slate-500 text-center mt-3">
            Press Enter to send, Shift + Enter for new line
          </p>
        </div>
      </div>
    </div>
  );
}

function SuggestedPrompt({ text, onClick }: { text: string; onClick: (text: string) => void }) {
  return (
    <button
      onClick={() => onClick(text)}
      className="text-left px-4 py-3 bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700/50 hover:border-slate-600 rounded-xl transition-all duration-200 text-slate-300 hover:text-white text-sm group"
    >
      <span className="group-hover:translate-x-1 inline-block transition-transform duration-200">{text}</span>
    </button>
  );
}
