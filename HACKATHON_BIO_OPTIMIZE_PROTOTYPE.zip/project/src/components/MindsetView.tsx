import { useState } from 'react';
import { ChatInterface } from './ChatInterface';
import { Shield, Zap } from 'lucide-react';

type MindsetViewProps = {
  userId: string;
};

export function MindsetView({ userId }: MindsetViewProps) {
  const [selectedMode, setSelectedMode] = useState<string | null>(null);

  const modes = [
    {
      id: 'stoic',
      name: 'Stoic Advisor',
      description: 'Ancient wisdom for modern challenges. Focus on what you can control.',
      icon: Shield,
      color: 'from-slate-600 to-slate-800',
    },
    {
      id: 'motivational',
      name: 'Motivational Coach',
      description: 'High-energy motivation to push your limits and achieve greatness.',
      icon: Zap,
      color: 'from-orange-600 to-red-600',
    },
  ];

  if (selectedMode) {
    const mode = modes.find((m) => m.id === selectedMode);
    return (
      <div className="h-full flex flex-col">
        <div className="bg-slate-800 border-b border-slate-700 p-4">
          <button
            onClick={() => setSelectedMode(null)}
            className="text-blue-400 hover:text-blue-300 text-sm transition-colors"
          >
            ← Change Mode
          </button>
        </div>
        <div className="flex-1">
          <ChatInterface
            userId={userId}
            mode={selectedMode}
            title={mode?.name || ''}
            description={mode?.description || ''}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-slate-900 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-3">Choose Your Mindset Coach</h2>
          <p className="text-slate-400 text-lg">Select a coaching style that resonates with you</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {modes.map((mode) => {
            const Icon = mode.icon;
            return (
              <button
                key={mode.id}
                onClick={() => setSelectedMode(mode.id)}
                className="group relative overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 rounded-2xl p-8 hover:border-slate-600 transition-all duration-300 hover:shadow-2xl hover:scale-105"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${mode.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />

                <div className="relative z-10">
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-br ${mode.color} mb-6 shadow-lg`}>
                    <Icon size={32} className="text-white" />
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-3">{mode.name}</h3>
                  <p className="text-slate-400 leading-relaxed">{mode.description}</p>

                  <div className="mt-6 inline-flex items-center text-blue-400 font-medium">
                    Start Session
                    <svg className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
