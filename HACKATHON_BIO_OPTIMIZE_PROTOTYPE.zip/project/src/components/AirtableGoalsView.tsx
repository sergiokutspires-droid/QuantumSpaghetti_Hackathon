import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAirtableGoals } from '../hooks/useAirtableGoals';
import { Goal } from '../types/airtableGoal';
import { StatusType } from '../lib/airtableFieldMapping';
import { GoalCard } from './airtable/GoalCard';
import { GoalDetailsPanel } from './airtable/GoalDetailsPanel';
import { SearchAndFilters } from './airtable/SearchAndFilters';
import { SyncIndicator } from './airtable/SyncIndicator';
import { Target, AlertCircle, Loader2 } from 'lucide-react';

export function AirtableGoalsView() {
  const {
    goals,
    loading,
    error,
    lastSyncedAt,
    isOnline,
    syncing,
    updateGoal,
    manualRefresh,
  } = useAirtableGoals();

  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusType | 'all'>('all');

  const filteredGoals = useMemo(() => {
    return goals.filter((goal) => {
      const matchesSearch = goal.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || goal.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [goals, searchQuery, statusFilter]);

  const handleUpdateGoal = async (goalId: string, updates: Partial<Goal>): Promise<boolean> => {
    const success = await updateGoal(goalId, updates);
    if (success && selectedGoal?.id === goalId) {
      const updatedGoal = goals.find((g) => g.id === goalId);
      if (updatedGoal) {
        setSelectedGoal(updatedGoal);
      }
    }
    return success;
  };

  if (loading && goals.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
        <div className="text-center">
          <Loader2 size={48} className="text-blue-400 animate-spin mx-auto mb-4" />
          <p className="text-slate-400">Loading goals...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="h-full flex flex-col lg:flex-row">
        <div className={`flex-shrink-0 flex flex-col border-r border-slate-800/50 bg-slate-900/50 ${selectedGoal ? 'hidden lg:flex lg:w-[400px]' : 'w-full'}`}>
          <div className="flex-shrink-0 p-6 border-b border-slate-800/50">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-1">
                  Goals Roadmap
                </h1>
                <p className="text-slate-400 text-sm">
                  {filteredGoals.length} {filteredGoals.length === 1 ? 'goal' : 'goals'}
                </p>
              </div>
            </div>

            <SearchAndFilters
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              statusFilter={statusFilter}
              onStatusFilterChange={setStatusFilter}
            />

            <div className="mt-4 flex items-center justify-between">
              <SyncIndicator
                lastSyncedAt={lastSyncedAt}
                isOnline={isOnline}
                syncing={syncing}
                onRefresh={manualRefresh}
              />
            </div>

            {!isOnline && (
              <div className="mt-3 p-3 bg-orange-500/10 border border-orange-500/30 rounded-lg">
                <p className="text-xs text-orange-300">
                  You're offline. Showing last synced data.
                </p>
              </div>
            )}

            {error && (
              <div className="mt-3 p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex items-start gap-2">
                <AlertCircle size={16} className="text-red-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-red-300">{error}</p>
              </div>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {filteredGoals.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-slate-800/50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target size={32} className="text-slate-600" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">No goals found</h3>
                <p className="text-slate-400 text-sm">
                  {searchQuery || statusFilter !== 'all'
                    ? 'Try adjusting your filters'
                    : 'Add goals in Airtable to get started'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredGoals.map((goal) => (
                  <GoalCard
                    key={goal.id}
                    goal={goal}
                    isSelected={selectedGoal?.id === goal.id}
                    onClick={() => setSelectedGoal(goal)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <div className={`flex-1 ${selectedGoal ? 'block' : 'hidden lg:flex lg:items-center lg:justify-center'}`}>
          <AnimatePresence mode="wait">
            {selectedGoal ? (
              <motion.div
                key={selectedGoal.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full"
              >
                <GoalDetailsPanel
                  goal={selectedGoal}
                  onClose={() => setSelectedGoal(null)}
                  onUpdateGoal={handleUpdateGoal}
                />
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center p-8"
              >
                <div className="w-24 h-24 bg-gradient-to-br from-blue-600/20 to-cyan-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Target size={40} className="text-blue-400" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Select a Goal</h2>
                <p className="text-slate-400">
                  Choose a goal from the list to view its 4-week roadmap
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
