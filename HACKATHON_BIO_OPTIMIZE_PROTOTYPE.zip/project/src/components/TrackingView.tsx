import { useState, useEffect } from 'react';
import { supabase, DailyMetrics, Gamification } from '../lib/supabase';
import { Save, TrendingUp } from 'lucide-react';

type TrackingViewProps = {
  userId: string;
};

export function TrackingView({ userId }: TrackingViewProps) {
  const [metrics, setMetrics] = useState<Partial<DailyMetrics>>({
    meditation_time_minutes: 0,
    journaling_time_minutes: 0,
    stress_level_1_10: 5,
    mood_score_1_10: 5,
    sleep_quality_1_10: 5,
    water_intake_liters: 0,
    steps_per_day: 0,
    exercise_minutes: 0,
    resting_heart_rate_bpm: 0,
    weight_kg: 0,
    energy_level_1_10: 5,
    meals_eaten: 0,
    protein_intake_grams: 0,
    fruit_vegetable_servings: 0,
    sugar_alcohol_consumption: '',
    deep_work_hours: 0,
    reading_time_minutes: 0,
    study_time_minutes: 0,
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    loadTodayMetrics();
  }, [userId]);

  const loadTodayMetrics = async () => {
    const today = new Date().toISOString().split('T')[0];
    const { data } = await supabase
      .from('daily_metrics')
      .select('*')
      .eq('user_id', userId)
      .eq('date', today)
      .maybeSingle();

    if (data) {
      setMetrics(data);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    try {
      const today = new Date().toISOString().split('T')[0];

      const { error } = await supabase
        .from('daily_metrics')
        .upsert(
          {
            user_id: userId,
            date: today,
            ...metrics,
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'user_id,date' }
        );

      if (error) throw error;

      const { data: gamification } = await supabase
        .from('gamification')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (gamification) {
        const xpGained = 10;
        const newXP = gamification.xp + xpGained;
        const newLevel = Math.floor(newXP / 100) + 1;

        await supabase
          .from('gamification')
          .update({
            xp: newXP,
            level: newLevel,
            current_streak: gamification.current_streak + 1,
            longest_streak: Math.max(gamification.longest_streak, gamification.current_streak + 1),
          })
          .eq('user_id', userId);
      }

      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (error) {
      console.error('Error saving metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateMetric = (key: string, value: number | string) => {
    setMetrics((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="h-full overflow-y-auto bg-slate-900 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Daily Tracking</h2>
          <p className="text-slate-400">Track your daily metrics to optimize your performance</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
              <TrendingUp className="mr-2" size={20} />
              Mental Wellness
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <NumberInput
                label="Meditation (minutes)"
                value={metrics.meditation_time_minutes || 0}
                onChange={(v) => updateMetric('meditation_time_minutes', v)}
              />
              <NumberInput
                label="Journaling (minutes)"
                value={metrics.journaling_time_minutes || 0}
                onChange={(v) => updateMetric('journaling_time_minutes', v)}
              />
              <SliderInput
                label="Stress Level"
                value={metrics.stress_level_1_10 || 5}
                onChange={(v) => updateMetric('stress_level_1_10', v)}
                min={1}
                max={10}
              />
              <SliderInput
                label="Mood Score"
                value={metrics.mood_score_1_10 || 5}
                onChange={(v) => updateMetric('mood_score_1_10', v)}
                min={1}
                max={10}
              />
              <SliderInput
                label="Energy Level"
                value={metrics.energy_level_1_10 || 5}
                onChange={(v) => updateMetric('energy_level_1_10', v)}
                min={1}
                max={10}
              />
              <SliderInput
                label="Sleep Quality"
                value={metrics.sleep_quality_1_10 || 5}
                onChange={(v) => updateMetric('sleep_quality_1_10', v)}
                min={1}
                max={10}
              />
            </div>
          </div>

          <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-semibold text-white mb-4">Physical Health</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <NumberInput
                label="Water Intake (liters)"
                value={metrics.water_intake_liters || 0}
                onChange={(v) => updateMetric('water_intake_liters', v)}
                step={0.1}
              />
              <NumberInput
                label="Steps"
                value={metrics.steps_per_day || 0}
                onChange={(v) => updateMetric('steps_per_day', v)}
              />
              <NumberInput
                label="Exercise (minutes)"
                value={metrics.exercise_minutes || 0}
                onChange={(v) => updateMetric('exercise_minutes', v)}
              />
              <NumberInput
                label="Resting Heart Rate (bpm)"
                value={metrics.resting_heart_rate_bpm || 0}
                onChange={(v) => updateMetric('resting_heart_rate_bpm', v)}
              />
              <NumberInput
                label="Weight (kg)"
                value={metrics.weight_kg || 0}
                onChange={(v) => updateMetric('weight_kg', v)}
                step={0.1}
              />
            </div>
          </div>

          <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-semibold text-white mb-4">Nutrition</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <NumberInput
                label="Meals Eaten"
                value={metrics.meals_eaten || 0}
                onChange={(v) => updateMetric('meals_eaten', v)}
              />
              <NumberInput
                label="Protein (grams)"
                value={metrics.protein_intake_grams || 0}
                onChange={(v) => updateMetric('protein_intake_grams', v)}
              />
              <NumberInput
                label="Fruits & Vegetables (servings)"
                value={metrics.fruit_vegetable_servings || 0}
                onChange={(v) => updateMetric('fruit_vegetable_servings', v)}
              />
              <TextInput
                label="Sugar/Alcohol Consumption"
                value={metrics.sugar_alcohol_consumption || ''}
                onChange={(v) => updateMetric('sugar_alcohol_consumption', v)}
              />
            </div>
          </div>

          <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-semibold text-white mb-4">Productivity</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <NumberInput
                label="Deep Work (hours)"
                value={metrics.deep_work_hours || 0}
                onChange={(v) => updateMetric('deep_work_hours', v)}
                step={0.5}
              />
              <NumberInput
                label="Reading (minutes)"
                value={metrics.reading_time_minutes || 0}
                onChange={(v) => updateMetric('reading_time_minutes', v)}
              />
              <NumberInput
                label="Study (minutes)"
                value={metrics.study_time_minutes || 0}
                onChange={(v) => updateMetric('study_time_minutes', v)}
              />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button
              type="submit"
              disabled={loading}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white font-medium px-6 py-3 rounded-lg transition-colors duration-200"
            >
              <Save size={20} />
              <span>{loading ? 'Saving...' : 'Save Metrics'}</span>
            </button>

            {success && (
              <span className="text-green-400 font-medium">✓ Saved successfully! +10 XP</span>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

function NumberInput({
  label,
  value,
  onChange,
  step = 1,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  step?: number;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-2">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
        step={step}
        className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      />
    </div>
  );
}

function SliderInput({
  label,
  value,
  onChange,
  min,
  max,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-2">
        {label}: {value}
      </label>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer slider"
      />
    </div>
  );
}

function TextInput({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-2">{label}</label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      />
    </div>
  );
}
