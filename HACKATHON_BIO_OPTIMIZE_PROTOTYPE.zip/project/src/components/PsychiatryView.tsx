import { useState } from 'react';
import { ChatInterface } from './ChatInterface';
import { MessageCircle, ClipboardList } from 'lucide-react';

type PsychiatryViewProps = {
  userId: string;
};

export function PsychiatryView({ userId }: PsychiatryViewProps) {
  const [selectedMode, setSelectedMode] = useState<string | null>(null);

  const modes = [
    {
      id: 'psychiatry_talk',
      name: 'Supportive Counseling',
      description: 'Empathetic listening and supportive conversation for mental well-being',
      icon: MessageCircle,
      color: 'from-green-600 to-teal-600',
      systemPrompt: 'You are a compassionate and empathetic mental health counselor. Listen actively to the patient, validate their feelings, provide emotional support, and help them explore their thoughts and emotions. Use reflective listening, ask open-ended questions, and create a safe, non-judgmental space. Do NOT mention goals or biohacking - focus purely on mental health and emotional well-being. Maintain professional boundaries and recommend professional help when appropriate.',
    },
    {
      id: 'psychiatry_diagnostic',
      name: 'Diagnostic Assessment',
      description: 'Structured symptom evaluation following DSM-5 criteria',
      icon: ClipboardList,
      color: 'from-blue-600 to-cyan-600',
      systemPrompt: 'You are a clinical mental health assessor trained in DSM-5 diagnostic criteria. Conduct a thorough, structured interview to gather information about symptoms, their duration, severity, and impact on daily functioning. Ask specific questions about mood, anxiety, sleep patterns, appetite, concentration, and social functioning. Document symptoms systematically and provide a structured summary that can be shared with a healthcare provider. Do NOT mention goals or biohacking. This is a pre-diagnostic tool - always recommend professional evaluation for actual diagnosis and treatment.',
    },
  ];

  if (selectedMode) {
    const mode = modes.find((m) => m.id === selectedMode);
    return (
      <div className="h-full flex flex-col">
        <div className="bg-gradient-to-r from-slate-900/95 to-slate-800/95 backdrop-blur-xl border-b border-slate-700/50 p-4">
          <button
            onClick={() => setSelectedMode(null)}
            className="text-blue-400 hover:text-cyan-400 text-sm font-medium transition-colors flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Change Mode
          </button>
        </div>
        <div className="flex-1">
          <ChatInterface
            userId={userId}
            mode={selectedMode}
            title={mode?.name || ''}
            description={mode?.description || ''}
            systemPrompt={mode?.systemPrompt}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-slate-900 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-3">Psychiatry Assistant</h2>
          <p className="text-slate-400 text-lg">Choose your support approach</p>
          <div className="mt-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 text-left">
            <p className="text-yellow-200 text-sm">
              <strong>Disclaimer:</strong> This is not a replacement for professional medical advice, diagnosis, or treatment.
              The diagnostic flow is designed to help organize symptom information for your healthcare provider.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          {modes.map((mode) => {
            const Icon = mode.icon;
            return (
              <button
                key={mode.id}
                onClick={() => setSelectedMode(mode.id)}
                className="group relative overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 rounded-2xl p-8 hover:border-slate-600 transition-all duration-300 hover:shadow-2xl hover:scale-105"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${mode.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />

                <div className="relative z-10">
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-br ${mode.color} mb-6 shadow-lg`}>
                    <Icon size={32} className="text-white" />
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-3">{mode.name}</h3>
                  <p className="text-slate-400 leading-relaxed">{mode.description}</p>

                  <div className="mt-6 inline-flex items-center text-blue-400 font-medium">
                    Start Session
                    <svg className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
