import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import { Bot, User } from 'lucide-react';

type ChatMessageProps = {
  message: string;
  role: 'user' | 'assistant';
  timestamp?: string;
  isStreaming?: boolean;
};

export function ChatMessage({ message, role, timestamp, isStreaming }: ChatMessageProps) {
  const isUser = role === 'user';

  return (
    <div className={`flex gap-4 px-4 py-6 ${isUser ? 'bg-transparent' : 'bg-slate-800/30'} hover:bg-slate-800/40 transition-colors duration-200`}>
      <div className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center shadow-lg ${
        isUser
          ? 'bg-gradient-to-br from-blue-600 to-cyan-600'
          : 'bg-gradient-to-br from-slate-700 to-slate-600'
      }`}>
        {isUser ? <User size={20} className="text-white" /> : <Bot size={20} className="text-white" />}
      </div>

      <div className="flex-1 min-w-0 pt-1">
        <div className="flex items-center gap-3 mb-2">
          <span className="font-semibold text-white text-sm">
            {isUser ? 'You' : 'AI Assistant'}
          </span>
          {timestamp && (
            <span className="text-xs text-slate-500">
              {new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          )}
        </div>

        <div className="prose prose-invert prose-slate max-w-none">
          {isUser ? (
            <p className="text-slate-200 whitespace-pre-wrap leading-relaxed">{message}</p>
          ) : (
            <div className="text-slate-200 markdown-content">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                rehypePlugins={[rehypeHighlight]}
                components={{
                  p: ({ children }) => <p className="mb-4 last:mb-0 leading-relaxed">{children}</p>,
                  ul: ({ children }) => <ul className="list-disc list-inside mb-4 space-y-1">{children}</ul>,
                  ol: ({ children }) => <ol className="list-decimal list-inside mb-4 space-y-1">{children}</ol>,
                  li: ({ children }) => <li className="text-slate-200">{children}</li>,
                  h1: ({ children }) => <h1 className="text-2xl font-bold mb-3 mt-6 text-white">{children}</h1>,
                  h2: ({ children }) => <h2 className="text-xl font-bold mb-3 mt-5 text-white">{children}</h2>,
                  h3: ({ children }) => <h3 className="text-lg font-bold mb-2 mt-4 text-white">{children}</h3>,
                  blockquote: ({ children }) => (
                    <blockquote className="border-l-4 border-blue-500 pl-4 py-2 my-4 italic text-slate-300 bg-slate-800/50 rounded-r">
                      {children}
                    </blockquote>
                  ),
                  code: ({ inline, children, ...props }: any) =>
                    inline ? (
                      <code className="bg-slate-700/50 text-cyan-400 px-1.5 py-0.5 rounded text-sm font-mono" {...props}>
                        {children}
                      </code>
                    ) : (
                      <code className="block bg-slate-900/50 p-4 rounded-lg my-4 text-sm font-mono overflow-x-auto border border-slate-700" {...props}>
                        {children}
                      </code>
                    ),
                  pre: ({ children }) => <div className="my-4">{children}</div>,
                  a: ({ children, href }) => (
                    <a href={href} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300 underline">
                      {children}
                    </a>
                  ),
                  strong: ({ children }) => <strong className="font-bold text-white">{children}</strong>,
                  table: ({ children }) => (
                    <div className="overflow-x-auto my-4">
                      <table className="min-w-full divide-y divide-slate-700 border border-slate-700 rounded-lg">
                        {children}
                      </table>
                    </div>
                  ),
                  thead: ({ children }) => <thead className="bg-slate-800">{children}</thead>,
                  tbody: ({ children }) => <tbody className="divide-y divide-slate-700">{children}</tbody>,
                  tr: ({ children }) => <tr className="hover:bg-slate-800/50">{children}</tr>,
                  th: ({ children }) => <th className="px-4 py-2 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">{children}</th>,
                  td: ({ children }) => <td className="px-4 py-2 text-sm text-slate-200">{children}</td>,
                }}
              >
                {message}
              </ReactMarkdown>
              {isStreaming && (
                <span className="inline-block w-2 h-4 bg-blue-500 animate-pulse ml-1"></span>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
