import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Target, Plus, Check, Clock, Trophy, Calendar, TrendingUp, Flag, X } from 'lucide-react';

type GoalsViewProps = {
  userId: string;
};

type UserGoal = {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  goal_type: string;
  status: string;
  target_date?: string;
  created_at: string;
};

export function GoalsView({ userId }: GoalsViewProps) {
  const [goals, setGoals] = useState<UserGoal[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    goal_type: 'health',
    target_date: '',
  });

  useEffect(() => {
    loadGoals();
  }, [userId]);

  const loadGoals = async () => {
    const { data } = await supabase
      .from('user_goals')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (data) setGoals(data);
  };

  const addGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoal.title.trim()) return;

    await supabase.from('user_goals').insert({
      user_id: userId,
      title: newGoal.title,
      description: newGoal.description,
      goal_type: newGoal.goal_type,
      target_date: newGoal.target_date || null,
    });

    setNewGoal({ title: '', description: '', goal_type: 'health', target_date: '' });
    setShowForm(false);
    loadGoals();
  };

  const toggleGoalStatus = async (goal: UserGoal) => {
    const newStatus = goal.status === 'completed' ? 'active' : 'completed';
    await supabase
      .from('user_goals')
      .update({ status: newStatus })
      .eq('id', goal.id);

    loadGoals();
  };

  const deleteGoal = async (goalId: string) => {
    if (confirm('Are you sure you want to delete this goal?')) {
      await supabase
        .from('user_goals')
        .delete()
        .eq('id', goalId);

      loadGoals();
    }
  };

  const getGoalIcon = (type: string) => {
    switch (type) {
      case 'health': return <Target className="w-5 h-5" />;
      case 'mental': return <TrendingUp className="w-5 h-5" />;
      case 'productivity': return <Clock className="w-5 h-5" />;
      case 'short_term': return <Flag className="w-5 h-5" />;
      case 'long_term': return <Trophy className="w-5 h-5" />;
      default: return <Target className="w-5 h-5" />;
    }
  };

  const getGoalColor = (type: string) => {
    switch (type) {
      case 'health': return 'from-green-500 to-emerald-500';
      case 'mental': return 'from-blue-500 to-cyan-500';
      case 'productivity': return 'from-orange-500 to-amber-500';
      case 'short_term': return 'from-pink-500 to-rose-500';
      case 'long_term': return 'from-purple-500 to-violet-500';
      default: return 'from-slate-500 to-slate-600';
    }
  };

  const activeGoals = goals.filter(g => g.status === 'active');
  const completedGoals = goals.filter(g => g.status === 'completed');

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="flex-shrink-0 bg-gradient-to-r from-slate-900/95 to-slate-800/95 backdrop-blur-xl border-b border-slate-700/50 px-8 py-6 shadow-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Target size={24} className="text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">My Goals</h2>
              <p className="text-slate-400 text-sm mt-0.5">Track and manage your personal goals</p>
            </div>
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-xl transition-all duration-200 shadow-lg hover:scale-105 font-medium"
          >
            <Plus size={20} />
            <span>New Goal</span>
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
        {showForm && (
          <div className="max-w-2xl mx-auto mb-8 bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-white">Create New Goal</h3>
              <button
                onClick={() => setShowForm(false)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            <form onSubmit={addGoal} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Goal Title</label>
                <input
                  type="text"
                  value={newGoal.title}
                  onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                  placeholder="e.g., Lose 10kg, Run a marathon, Learn Spanish"
                  className="w-full bg-slate-900/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Description</label>
                <textarea
                  value={newGoal.description}
                  onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                  placeholder="Describe your goal in more detail..."
                  rows={3}
                  className="w-full bg-slate-900/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Goal Type</label>
                  <select
                    value={newGoal.goal_type}
                    onChange={(e) => setNewGoal({ ...newGoal, goal_type: e.target.value })}
                    className="w-full bg-slate-900/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="health">Health</option>
                    <option value="mental">Mental</option>
                    <option value="productivity">Productivity</option>
                    <option value="short_term">Short Term</option>
                    <option value="long_term">Long Term</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Target Date</label>
                  <input
                    type="date"
                    value={newGoal.target_date}
                    onChange={(e) => setNewGoal({ ...newGoal, target_date: e.target.value })}
                    className="w-full bg-slate-900/50 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-6 py-3 rounded-xl transition-all duration-200 font-medium shadow-lg hover:scale-105"
                >
                  Create Goal
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-6 py-3 bg-slate-700/50 hover:bg-slate-600/50 text-slate-300 hover:text-white rounded-xl transition-all duration-200 border border-slate-600"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="max-w-4xl mx-auto space-y-8">
          {activeGoals.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Clock size={20} className="text-blue-400" />
                Active Goals ({activeGoals.length})
              </h3>
              <div className="grid gap-4">
                {activeGoals.map((goal) => (
                  <div
                    key={goal.id}
                    className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 hover:bg-slate-800/70 transition-all duration-200 group"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 bg-gradient-to-br ${getGoalColor(goal.goal_type)} rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg`}>
                        {getGoalIcon(goal.goal_type)}
                      </div>

                      <div className="flex-1 min-w-0">
                        <h4 className="text-lg font-semibold text-white mb-1">{goal.title}</h4>
                        {goal.description && (
                          <p className="text-slate-400 text-sm mb-3">{goal.description}</p>
                        )}
                        <div className="flex items-center gap-4 text-xs text-slate-500">
                          <span className="capitalize">{goal.goal_type.replace('_', ' ')}</span>
                          {goal.target_date && (
                            <>
                              <span>•</span>
                              <span className="flex items-center gap-1">
                                <Calendar size={12} />
                                {new Date(goal.target_date).toLocaleDateString()}
                              </span>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => toggleGoalStatus(goal)}
                          className="p-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 rounded-lg transition-colors"
                          title="Mark as completed"
                        >
                          <Check size={18} />
                        </button>
                        <button
                          onClick={() => deleteGoal(goal.id)}
                          className="p-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors"
                          title="Delete goal"
                        >
                          <X size={18} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {completedGoals.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Trophy size={20} className="text-green-400" />
                Completed Goals ({completedGoals.length})
              </h3>
              <div className="grid gap-4">
                {completedGoals.map((goal) => (
                  <div
                    key={goal.id}
                    className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/30 rounded-2xl p-6 opacity-75 hover:opacity-100 transition-all duration-200 group"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 bg-gradient-to-br ${getGoalColor(goal.goal_type)} opacity-50 rounded-xl flex items-center justify-center flex-shrink-0`}>
                        {getGoalIcon(goal.goal_type)}
                      </div>

                      <div className="flex-1 min-w-0">
                        <h4 className="text-lg font-semibold text-slate-400 mb-1 line-through">{goal.title}</h4>
                        {goal.description && (
                          <p className="text-slate-500 text-sm mb-3">{goal.description}</p>
                        )}
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-green-400 flex items-center gap-1">
                            <Check size={12} />
                            Completed
                          </span>
                        </div>
                      </div>

                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => toggleGoalStatus(goal)}
                          className="p-2 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 rounded-lg transition-colors"
                          title="Mark as active"
                        >
                          <Clock size={18} />
                        </button>
                        <button
                          onClick={() => deleteGoal(goal.id)}
                          className="p-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors"
                          title="Delete goal"
                        >
                          <X size={18} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {goals.length === 0 && (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-slate-800/50 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Target size={36} className="text-slate-600" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-3">No Goals Yet</h3>
              <p className="text-slate-400 mb-6 max-w-md mx-auto">
                Start your journey by creating your first goal. Break down big dreams into achievable milestones.
              </p>
              <button
                onClick={() => setShowForm(true)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-xl transition-all duration-200 shadow-lg hover:scale-105 font-medium"
              >
                <Plus size={20} />
                <span>Create Your First Goal</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
