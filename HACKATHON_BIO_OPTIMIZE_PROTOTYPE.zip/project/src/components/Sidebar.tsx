import { MessageSquare, Brain, Heart, BarChart3, Target, LogOut, Map, Calendar, Sparkles } from 'lucide-react';

type SidebarProps = {
  currentView: string;
  onViewChange: (view: string) => void;
  onSignOut: () => void;
};

export function Sidebar({ currentView, onViewChange, onSignOut }: SidebarProps) {
  const menuItems = [
    { id: 'enlightenment', label: 'Enlightenment', icon: Sparkles },
    { id: 'roadmap', label: 'Roadmap', icon: Map },
    { id: 'airtable-goals', label: 'My Goals', icon: Calendar },
    { id: 'biohacking', label: 'Biohacking Chat', icon: MessageSquare },
    { id: 'mindset', label: 'Mindset Coach', icon: Brain },
    { id: 'psychiatry', label: 'Psychiatry Assistant', icon: Heart },
    { id: 'tracking', label: 'Daily Tracking', icon: Target },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  ];

  return (
    <div className="w-64 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 h-screen flex flex-col border-r border-slate-800/50 shadow-2xl">
      <div className="p-6 border-b border-slate-800/50">
        <div className="flex items-center space-x-3 mb-2">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">BioOptimize</h1>
        </div>
        <p className="text-slate-500 text-xs font-medium tracking-wide">ELEVATE YOUR POTENTIAL</p>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`group w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden ${
                currentView === item.id
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-500/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <div className={`p-2 rounded-lg transition-all duration-300 ${
                currentView === item.id
                  ? 'bg-white/20'
                  : 'bg-slate-800/50 group-hover:bg-slate-700/50'
              }`}>
                <Icon size={18} />
              </div>
              <span className="font-medium text-sm">{item.label}</span>
              {currentView === item.id && (
                <div className="absolute right-2 w-1.5 h-8 bg-white rounded-full"></div>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800/50">
        <button
          onClick={onSignOut}
          className="group w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-300 border border-transparent hover:border-red-500/30"
        >
          <div className="p-2 rounded-lg bg-slate-800/50 group-hover:bg-red-500/20 transition-all duration-300">
            <LogOut size={18} />
          </div>
          <span className="font-medium text-sm">Sign Out</span>
        </button>
      </div>
    </div>
  );
}
