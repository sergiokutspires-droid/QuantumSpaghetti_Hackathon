import { useState, useEffect, useRef } from 'react';
import { Loader2, Zap, Flame, Leaf, Compass, AlertCircle, Send, MessageSquare, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { generateFallbackResponse } from '../lib/fallbackAI';

type EnlightenmentViewProps = {
  userId: string;
};

type AIMode = 'goal' | 'wellness' | null;

type ChatMessage = {
  role: 'user' | 'assistant';
  message: string;
  timestamp: Date;
};

declare global {
  interface Window {
    ElevenLabsConversation: any;
  }
}

export function EnlightenmentView({ userId }: EnlightenmentViewProps) {
  const [selectedMode, setSelectedMode] = useState<AIMode>(null);
  const [isConversationActive, setIsConversationActive] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [sdkLoaded, setSdkLoaded] = useState(false);
  const [primaryMetric, setPrimaryMetric] = useState('Select your AI companion above');
  const [agentMessage, setAgentMessage] = useState('Click the crystal to begin your session');
  const [showMessage, setShowMessage] = useState<{ text: string; type: 'error' | 'success' | 'info' } | null>(null);

  const [showChat, setShowChat] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [textInput, setTextInput] = useState('');
  const [isSendingMessage, setIsSendingMessage] = useState(false);

  const conversationRef = useRef<any>(null);
  const checkIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const config = {
    agents: {
      goal: {
        agentId: import.meta.env.VITE_ELEVENLABS_GOAL_AGENT_ID || 'agent_2301k9ffgscte5zrsh4tntnwnr72',
        webhook: import.meta.env.VITE_N8N_GOAL_WEBHOOK || 'https://vamosgigiox.app.n8n.cloud/webhook-test/elevenlabs-goals',
      },
      wellness: {
        agentId: import.meta.env.VITE_ELEVENLABS_WELLNESS_AGENT_ID || 'agent_3601k9fsz3a2e93vt7pm6v0skmmb',
        webhook: import.meta.env.VITE_N8N_WELLNESS_WEBHOOK || 'https://vamosgigiox.app.n8n.cloud/webhook/wellness-assessment',
      },
    },
  };

  useEffect(() => {
    createStars();
    checkSDKLoaded();

    return () => {
      if (checkIntervalRef.current) {
        clearInterval(checkIntervalRef.current);
      }
      if (conversationRef.current) {
        try {
          conversationRef.current.endSession();
        } catch (error) {
          console.error('Error cleaning up conversation:', error);
        }
      }
    };
  }, []);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages]);

  const checkSDKLoaded = () => {
    if (typeof window !== 'undefined' && window.ElevenLabsConversation) {
      setSdkLoaded(true);
      console.log('✅ ElevenLabs SDK loaded');
      return;
    }

    let attempts = 0;
    checkIntervalRef.current = setInterval(() => {
      attempts++;
      if (typeof window !== 'undefined' && window.ElevenLabsConversation) {
        setSdkLoaded(true);
        console.log('✅ ElevenLabs SDK loaded');
        if (checkIntervalRef.current) clearInterval(checkIntervalRef.current);
      } else if (attempts > 20) {
        console.warn('⚠️ ElevenLabs SDK failed to load after 10 seconds');
        if (checkIntervalRef.current) clearInterval(checkIntervalRef.current);
      }
    }, 500);
  };

  const createStars = () => {
    const starsContainer = document.getElementById('stars-container');
    if (!starsContainer) return;

    starsContainer.innerHTML = '';
    for (let i = 0; i < 150; i++) {
      const star = document.createElement('div');
      star.className = 'absolute w-0.5 h-0.5 bg-white rounded-full opacity-20';
      star.style.left = Math.random() * 100 + '%';
      star.style.top = Math.random() * 100 + '%';
      star.style.animation = `twinkle ${Math.random() * 4 + 2}s ease-in-out ${Math.random() * 4}s infinite`;
      starsContainer.appendChild(star);
    }
  };

  const displayMessage = (text: string, type: 'error' | 'success' | 'info' = 'info') => {
    setShowMessage({ text, type });
    setTimeout(() => setShowMessage(null), 5000);
  };


  const startConversation = async (isAutoReconnect = false) => {
    if (!selectedMode) {
      displayMessage('Please select a mode first (Goal Crystal or Wellness Coach)', 'error');
      return;
    }

    if (isConversationActive) {
      return;
    }

    if (!sdkLoaded) {
      displayMessage('Voice AI is still loading. Please wait a moment and try again.', 'info');
      return;
    }

    try {
      setIsLoading(true);
      if (!isAutoReconnect) {
        setPrimaryMetric('Connecting...');
        setAgentMessage('Initializing voice AI...');
      }

      const agentConfig = config.agents[selectedMode];

      if (typeof window !== 'undefined' && window.ElevenLabsConversation) {
        const Conversation = window.ElevenLabsConversation;

        console.log(`🚀 Starting ${selectedMode} conversation with agent ${agentConfig.agentId}`);

        conversationRef.current = await Conversation.startSession({
          agentId: agentConfig.agentId,

          onConnect: () => {
            console.log('✅ Connected to ElevenLabs');
            setIsConversationActive(true);
            setPrimaryMetric('🎙️ Listening');
            setAgentMessage("Speak now... I'm here to help!");
            setIsLoading(false);
            if (!isAutoReconnect) {
              displayMessage('Voice connection established!', 'success');
            }
          },

          onDisconnect: () => {
            console.log('🔌 Disconnected');
            handleConversationEnd();
          },

          onError: (error: Error) => {
            console.error('❌ Error:', error);
            displayMessage(`Connection error: ${error.message}`, 'error');
            handleConversationEnd();
          },

          onMessage: (message: any) => {
            console.log('📩 Message:', message);
            if (message.message) {
              const preview = message.message.substring(0, 100);
              setAgentMessage(preview + (message.message.length > 100 ? '...' : ''));

              const chatMsg: ChatMessage = {
                role: 'assistant',
                message: message.message,
                timestamp: new Date()
              };
              setChatMessages(prev => [...prev, chatMsg]);

              saveChatMessage('assistant', message.message);
            }
          },

          onModeChange: (mode: any) => {
            const modeText = mode.mode === 'listening' ? '🎙️ Listening' : '🗣️ Speaking';
            setPrimaryMetric(modeText);
            console.log(`🔄 Mode changed: ${mode.mode}`);
          },
        });

        await sendWebhookData(agentConfig.webhook, {
          event: 'conversation_started',
          mode: selectedMode,
          agentId: agentConfig.agentId,
          timestamp: new Date().toISOString(),
          sessionId: Date.now().toString(),
          userId,
        });

      } else {
        throw new Error('ElevenLabs SDK not loaded. Please refresh the page.');
      }

    } catch (error: any) {
      console.error('❌ Failed to start:', error);
      displayMessage(`Failed to connect: ${error.message}. Check microphone permissions!`, 'error');
      handleConversationEnd();
    }
  };

  const endConversation = async () => {
    if (conversationRef.current) {
      try {
        await conversationRef.current.endSession();
        console.log('✅ Session ended');
      } catch (error) {
        console.error('⚠️ Error ending session:', error);
      }
    }
    handleConversationEnd();
  };

  const handleConversationEnd = () => {
    setIsConversationActive(false);
    setIsLoading(false);
    setPrimaryMetric('Session Ended');
    setAgentMessage('Click the crystal to start a new session');
    conversationRef.current = null;
  };

  const sendWebhookData = async (webhookUrl: string, data: any) => {
    try {
      console.log('📤 Webhook:', webhookUrl);
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        const result = await response.json();
        console.log('✅ Webhook success:', result);
        return result;
      }
    } catch (error) {
      console.error('❌ Webhook error:', error);
    }
  };

  const saveChatMessage = async (role: 'user' | 'assistant', message: string) => {
    try {
      await supabase.from('chat_history').insert({
        user_id: userId,
        mode: `enlightenment_${selectedMode}`,
        message,
        role,
      });
    } catch (error) {
      console.error('Error saving chat message:', error);
    }
  };

  const sendTextMessage = async () => {
    if (!textInput.trim() || isSendingMessage) return;
    if (!selectedMode) {
      displayMessage('Please select a mode first', 'error');
      return;
    }

    const userMessage = textInput.trim();
    setTextInput('');
    setIsSendingMessage(true);

    const userChatMsg: ChatMessage = {
      role: 'user',
      message: userMessage,
      timestamp: new Date()
    };
    setChatMessages(prev => [...prev, userChatMsg]);
    saveChatMessage('user', userMessage);

    try {
      const agentConfig = config.agents[selectedMode];

      const { data: goals } = await supabase
        .from('user_goals')
        .select('*')
        .eq('user_id', userId)
        .eq('status', 'active');

      const today = new Date().toISOString().split('T')[0];
      const { data: metrics } = await supabase
        .from('daily_metrics')
        .select('*')
        .eq('user_id', userId)
        .eq('date', today)
        .maybeSingle();

      let aiResponse = '';

      try {
        const response = await fetch(agentConfig.webhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            user_id: userId,
            message: userMessage,
            mode: selectedMode,
            goals: goals || [],
            metrics: metrics || {},
            conversation_history: chatMessages.slice(-5),
          }),
        });

        if (response.ok) {
          const data = await response.json();
          aiResponse = data.response || data.message || data.text;
        }
      } catch (webhookError) {
        console.error('Webhook error, using fallback:', webhookError);
      }

      if (!aiResponse) {
        aiResponse = generateFallbackResponse(userMessage, goals || [], metrics, chatMessages);
      }

      const aiChatMsg: ChatMessage = {
        role: 'assistant',
        message: aiResponse,
        timestamp: new Date()
      };
      setChatMessages(prev => [...prev, aiChatMsg]);
      saveChatMessage('assistant', aiResponse);

    } catch (error) {
      console.error('Error sending text message:', error);
      displayMessage('Failed to send message. Please try again.', 'error');
    } finally {
      setIsSendingMessage(false);
    }
  };

  const handleCrystalClick = () => {
    if (isConversationActive) {
      endConversation();
    } else {
      startConversation();
    }
  };

  const handleModeSelect = (mode: AIMode) => {
    if (isConversationActive && selectedMode !== mode) {
      displayMessage('Please end the current conversation before switching modes', 'info');
      return;
    }
    setSelectedMode(mode);
    setChatMessages([]);
    const modeName = mode === 'goal' ? 'Goal Crystal' : 'Wellness Coach';
    setPrimaryMetric(`${modeName} Active`);
    setAgentMessage('Click the crystal to begin your voice session');
    console.log(`✅ Mode selected: ${mode}`);
  };

  return (
    <div className="h-full relative overflow-hidden bg-gradient-to-br from-slate-950 via-purple-950/20 to-slate-950 flex">
      <style>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.2; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.2); }
        }
        @keyframes breathe {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        @keyframes pulse-glow {
          0%, 100% { filter: drop-shadow(0 0 60px rgba(0, 245, 255, 0.4)); }
          50% { filter: drop-shadow(0 0 100px rgba(178, 75, 243, 0.8)); }
        }
        @keyframes sparkle {
          0%, 100% { opacity: 0; transform: scale(0); }
          50% { opacity: 1; transform: scale(1); }
        }
        @keyframes slide-down {
          from { transform: translate(-50%, -20px); opacity: 0; }
          to { transform: translate(-50%, 0); opacity: 1; }
        }
        .crystal-orb {
          animation: breathe 8s ease-in-out infinite;
          transition: all 0.4s ease;
        }
        .crystal-orb.active {
          animation: breathe 8s ease-in-out infinite, pulse-glow 2.5s ease-in-out infinite;
        }
        .crystal-orb:not(.disabled):hover {
          transform: scale(1.05);
        }
        .message-slide {
          animation: slide-down 0.4s ease;
        }
      `}</style>

      <div id="stars-container" className="fixed inset-0 pointer-events-none z-0" />

      <div className="flex-1 relative z-10 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-8 py-12">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-extrabold mb-3 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent tracking-wider">
              BIO_HACKING ENLIGHTENMENT
            </h1>
            <p className="text-slate-400 text-sm tracking-[0.3em] uppercase font-light">
              Elevate Your Consciousness
            </p>
          </div>

          {!sdkLoaded && (
            <div className="fixed top-24 left-1/2 transform -translate-x-1/2 px-8 py-4 rounded-2xl border backdrop-blur-xl z-50 bg-blue-500/20 border-blue-500/50 message-slide">
              <p className="text-white font-medium flex items-center gap-2">
                <Loader2 className="animate-spin" size={18} />
                Loading Voice AI SDK...
              </p>
            </div>
          )}

          {showMessage && (
            <div className={`fixed top-24 left-1/2 transform -translate-x-1/2 px-8 py-4 rounded-2xl border backdrop-blur-xl z-50 message-slide ${
              showMessage.type === 'error' ? 'bg-red-500/20 border-red-500/50' :
              showMessage.type === 'success' ? 'bg-green-500/20 border-green-500/50' :
              'bg-blue-500/20 border-blue-500/50'
            }`}>
              <p className="text-white font-medium flex items-center gap-2">
                {showMessage.type === 'error' && <AlertCircle size={18} />}
                {showMessage.text}
              </p>
            </div>
          )}

          <div className="flex flex-col items-center gap-12">
            <div className="flex flex-wrap justify-center gap-8">
              <button
                onClick={() => handleModeSelect('goal')}
                disabled={isConversationActive && selectedMode !== 'goal'}
                className={`group relative bg-white/5 backdrop-blur-xl border rounded-3xl p-10 cursor-pointer transition-all duration-500 hover:transform hover:-translate-y-2 min-w-[280px] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:transform-none ${
                  selectedMode === 'goal'
                    ? 'border-cyan-400 bg-cyan-400/10 shadow-[0_0_60px_rgba(0,245,255,0.3)]'
                    : 'border-white/10 hover:border-cyan-400/30 hover:shadow-[0_20px_60px_rgba(0,245,255,0.15)]'
                }`}
              >
                <div className="text-6xl mb-6">🚀</div>
                <h2 className="text-2xl font-bold text-white mb-3">Goal Crystal</h2>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Strategic guidance & performance acceleration
                </p>
              </button>

              <button
                onClick={() => handleModeSelect('wellness')}
                disabled={isConversationActive && selectedMode !== 'wellness'}
                className={`group relative bg-white/5 backdrop-blur-xl border rounded-3xl p-10 cursor-pointer transition-all duration-500 hover:transform hover:-translate-y-2 min-w-[280px] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:transform-none ${
                  selectedMode === 'wellness'
                    ? 'border-purple-400 bg-purple-400/10 shadow-[0_0_60px_rgba(178,75,243,0.3)]'
                    : 'border-white/10 hover:border-purple-400/30 hover:shadow-[0_20px_60px_rgba(178,75,243,0.15)]'
                }`}
              >
                <div className="text-6xl mb-6">🧠</div>
                <h2 className="text-2xl font-bold text-white mb-3">Wellness Coach</h2>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Emotional balance & mental health support
                </p>
              </button>
            </div>

            <div className="flex flex-col items-center mt-12">
              <button
                onClick={handleCrystalClick}
                disabled={isLoading || !sdkLoaded}
                className={`crystal-orb w-72 h-72 relative cursor-pointer ${
                  isConversationActive ? 'active' : ''
                } ${(isLoading || !sdkLoaded) ? 'disabled opacity-50 cursor-not-allowed' : ''}`}
              >
                <div className={`w-full h-full rounded-full relative shadow-2xl transition-all duration-500 ${
                  selectedMode === 'wellness'
                    ? 'bg-gradient-to-br from-teal-400 via-purple-500 to-pink-500'
                    : 'bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-400'
                }`}>
                  <div className="absolute top-[15%] left-[15%] w-[70%] h-[70%] bg-white/40 rounded-full blur-2xl" />

                  <div className="absolute w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_10px_white] top-[25%] left-[35%]"
                       style={{ animation: 'sparkle 3s infinite 0s' }} />
                  <div className="absolute w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_10px_white] top-[45%] right-[25%]"
                       style={{ animation: 'sparkle 3s infinite 1s' }} />
                  <div className="absolute w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_10px_white] bottom-[30%] left-[40%]"
                       style={{ animation: 'sparkle 3s infinite 2s' }} />
                </div>
              </button>

              {isLoading && (
                <div className="mt-8">
                  <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
                </div>
              )}

              <div className="text-center mt-12 max-w-2xl px-4">
                <div className="text-2xl font-semibold text-cyan-400 mb-3 min-h-[32px]">
                  {primaryMetric}
                </div>
                <div className="text-slate-400 leading-relaxed min-h-[24px]">
                  {agentMessage}
                </div>
                {!sdkLoaded && (
                  <div className="text-sm text-slate-500 mt-2">
                    Waiting for Voice AI to load...
                  </div>
                )}
              </div>

              <button
                onClick={() => setShowChat(!showChat)}
                className="mt-8 flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl font-medium transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                <MessageSquare size={20} />
                {showChat ? 'Hide Chat' : 'Open Chat'}
              </button>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mt-16 w-full max-w-5xl">
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 text-center hover:border-cyan-400/30 hover:-translate-y-1 transition-all duration-300">
                <Zap className="w-8 h-8 mx-auto mb-3 text-cyan-400" />
                <div className="text-xs text-slate-400 uppercase tracking-wider mb-2">Focus Power</div>
                <div className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">--</div>
              </div>

              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 text-center hover:border-orange-400/30 hover:-translate-y-1 transition-all duration-300">
                <Flame className="w-8 h-8 mx-auto mb-3 text-orange-400" />
                <div className="text-xs text-slate-400 uppercase tracking-wider mb-2">Flow Streak</div>
                <div className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">--</div>
              </div>

              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 text-center hover:border-green-400/30 hover:-translate-y-1 transition-all duration-300">
                <Leaf className="w-8 h-8 mx-auto mb-3 text-green-400" />
                <div className="text-xs text-slate-400 uppercase tracking-wider mb-2">Balance</div>
                <div className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">--</div>
              </div>

              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 text-center hover:border-purple-400/30 hover:-translate-y-1 transition-all duration-300">
                <Compass className="w-8 h-8 mx-auto mb-3 text-purple-400" />
                <div className="text-xs text-slate-400 uppercase tracking-wider mb-2">Progress</div>
                <div className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">--</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showChat && (
        <div className="w-96 bg-slate-900/95 backdrop-blur-xl border-l border-slate-700 flex flex-col relative z-20">
          <div className="p-4 border-b border-slate-700 flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <MessageSquare size={20} />
              {selectedMode === 'goal' ? 'Goal Crystal' : selectedMode === 'wellness' ? 'Wellness Coach' : 'Chat'}
            </h3>
            <button
              onClick={() => setShowChat(false)}
              className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatMessages.length === 0 ? (
              <div className="text-center text-slate-500 mt-8">
                <MessageSquare size={48} className="mx-auto mb-4 opacity-50" />
                <p>No messages yet.</p>
                <p className="text-sm mt-2">Start chatting or use voice!</p>
              </div>
            ) : (
              chatMessages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      msg.role === 'user'
                        ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white'
                        : 'bg-slate-800 text-slate-200 border border-slate-700'
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{msg.message}</p>
                    <p className="text-xs opacity-60 mt-1">
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))
            )}
            <div ref={chatEndRef} />
          </div>

          <div className="p-4 border-t border-slate-700">
            <div className="flex gap-2">
              <input
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendTextMessage()}
                placeholder={selectedMode ? "Type your message..." : "Select a mode first..."}
                disabled={isSendingMessage || !selectedMode}
                className="flex-1 px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
              />
              <button
                onClick={sendTextMessage}
                disabled={isSendingMessage || !textInput.trim() || !selectedMode}
                className="px-4 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSendingMessage ? (
                  <Loader2 className="animate-spin" size={20} />
                ) : (
                  <Send size={20} />
                )}
              </button>
            </div>
            {!selectedMode && (
              <p className="text-xs text-slate-500 mt-2">Select a mode to start chatting</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
