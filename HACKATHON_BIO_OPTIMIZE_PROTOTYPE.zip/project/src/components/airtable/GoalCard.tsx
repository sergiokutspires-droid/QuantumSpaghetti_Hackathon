import { motion } from 'framer-motion';
import { Goal } from '../../types/airtableGoal';
import { Clock, TrendingUp } from 'lucide-react';
import { formatDistanceToNow } from '../../lib/dateUtils';
import { STATUS_OPTIONS } from '../../lib/airtableFieldMapping';

interface GoalCardProps {
  goal: Goal;
  isSelected: boolean;
  onClick: () => void;
}

export function GoalCard({ goal, isSelected, onClick }: GoalCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case STATUS_OPTIONS.DONE:
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case STATUS_OPTIONS.IN_PROGRESS:
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default:
        return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  return (
    <motion.button
      layout
      onClick={onClick}
      className={`w-full text-left p-5 rounded-xl border transition-all duration-300 ${
        isSelected
          ? 'bg-gradient-to-br from-blue-600/20 to-cyan-600/20 border-blue-500/50 shadow-lg shadow-blue-500/20'
          : 'bg-slate-800/50 border-slate-700/50 hover:border-slate-600 hover:bg-slate-800/70'
      }`}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <h3 className="text-lg font-semibold text-white line-clamp-2">{goal.title}</h3>
        <span
          className={`flex-shrink-0 px-2.5 py-1 text-xs font-medium rounded-lg border ${getStatusColor(
            goal.status
          )}`}
        >
          {goal.status}
        </span>
      </div>

      {goal.description && (
        <p className="text-sm text-slate-400 line-clamp-2 mb-3">{goal.description}</p>
      )}

      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <TrendingUp size={14} className="text-slate-500" />
          <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden w-24">
            <motion.div
              className={`h-full ${
                goal.progress === 100
                  ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                  : 'bg-gradient-to-r from-blue-500 to-cyan-500'
              }`}
              initial={{ width: 0 }}
              animate={{ width: `${goal.progress}%` }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
            />
          </div>
          <span className="text-xs text-slate-400 font-medium">{goal.progress}%</span>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-500">
          <Clock size={12} />
          <span>{formatDistanceToNow(new Date(goal.lastModified))}</span>
        </div>
      </div>
    </motion.button>
  );
}
