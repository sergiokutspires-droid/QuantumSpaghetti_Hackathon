import { Search, Filter } from 'lucide-react';
import { StatusType, STATUS_OPTIONS } from '../../lib/airtableFieldMapping';

interface SearchAndFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  statusFilter: StatusType | 'all';
  onStatusFilterChange: (status: StatusType | 'all') => void;
}

export function SearchAndFilters({
  searchQuery,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
}: SearchAndFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-3">
      <div className="flex-1 relative">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search goals..."
          className="w-full pl-10 pr-4 py-2.5 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
        />
      </div>

      <div className="relative">
        <Filter size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        <select
          value={statusFilter}
          onChange={(e) => onStatusFilterChange(e.target.value as StatusType | 'all')}
          className="w-full sm:w-48 pl-10 pr-4 py-2.5 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none cursor-pointer"
        >
          <option value="all">All Status</option>
          <option value={STATUS_OPTIONS.NOT_STARTED}>{STATUS_OPTIONS.NOT_STARTED}</option>
          <option value={STATUS_OPTIONS.IN_PROGRESS}>{STATUS_OPTIONS.IN_PROGRESS}</option>
          <option value={STATUS_OPTIONS.DONE}>{STATUS_OPTIONS.DONE}</option>
        </select>
      </div>
    </div>
  );
}
