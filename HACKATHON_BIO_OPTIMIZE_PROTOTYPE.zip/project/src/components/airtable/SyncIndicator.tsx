import { RefreshCw, WifiOff, Check } from 'lucide-react';
import { formatDistanceToNow } from '../../lib/dateUtils';

interface SyncIndicatorProps {
  lastSyncedAt: Date | null;
  isOnline: boolean;
  syncing: boolean;
  onRefresh: () => void;
}

export function SyncIndicator({ lastSyncedAt, isOnline, syncing, onRefresh }: SyncIndicatorProps) {
  return (
    <div className="flex items-center gap-3">
      {!isOnline && (
        <div className="flex items-center gap-2 px-3 py-1.5 bg-orange-500/10 border border-orange-500/30 rounded-lg">
          <WifiOff size={14} className="text-orange-400" />
          <span className="text-xs text-orange-300">Offline</span>
        </div>
      )}

      {lastSyncedAt && (
        <div className="flex items-center gap-2 text-slate-400 text-xs">
          <Check size={14} className="text-green-400" />
          <span>Synced {formatDistanceToNow(lastSyncedAt)}</span>
        </div>
      )}

      <button
        onClick={onRefresh}
        disabled={syncing}
        className="flex items-center gap-2 px-3 py-1.5 bg-slate-700/50 hover:bg-slate-600 disabled:opacity-50 text-white text-xs rounded-lg transition-all duration-200"
      >
        <RefreshCw size={14} className={syncing ? 'animate-spin' : ''} />
        <span>{syncing ? 'Syncing...' : 'Refresh'}</span>
      </button>
    </div>
  );
}
