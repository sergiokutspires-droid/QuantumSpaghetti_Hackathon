import { motion } from 'framer-motion';
import { Goal } from '../../types/airtableGoal';
import { WeekSection } from './WeekSection';
import { X, Target } from 'lucide-react';
import { STATUS_OPTIONS, StatusType } from '../../lib/airtableFieldMapping';

interface GoalDetailsPanelProps {
  goal: Goal | null;
  onClose: () => void;
  onUpdateGoal: (goalId: string, updates: Partial<Goal>) => Promise<boolean>;
}

export function GoalDetailsPanel({ goal, onClose, onUpdateGoal }: GoalDetailsPanelProps) {
  if (!goal) return null;

  const handleStatusChange = async (newStatus: StatusType) => {
    await onUpdateGoal(goal.id, { status: newStatus });
  };

  const handleProgressChange = async (newProgress: number) => {
    await onUpdateGoal(goal.id, { progress: newProgress });
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ duration: 0.3 }}
      className="h-full flex flex-col bg-gradient-to-br from-slate-900 to-slate-950"
    >
      <div className="flex-shrink-0 bg-gradient-to-r from-slate-900/95 to-slate-800/95 backdrop-blur-xl border-b border-slate-700/50 p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-4 flex-1">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0">
              <Target size={24} className="text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold text-white mb-2">{goal.title}</h2>
              {goal.description && (
                <p className="text-slate-400 leading-relaxed">{goal.description}</p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-slate-800/50 hover:bg-slate-700 rounded-xl transition-colors"
            aria-label="Close details"
          >
            <X size={20} className="text-slate-400" />
          </button>
        </div>

        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Status</label>
            <select
              value={goal.status}
              onChange={(e) => handleStatusChange(e.target.value as StatusType)}
              className="w-full px-4 py-2.5 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            >
              <option value={STATUS_OPTIONS.NOT_STARTED}>{STATUS_OPTIONS.NOT_STARTED}</option>
              <option value={STATUS_OPTIONS.IN_PROGRESS}>{STATUS_OPTIONS.IN_PROGRESS}</option>
              <option value={STATUS_OPTIONS.DONE}>{STATUS_OPTIONS.DONE}</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Progress: {goal.progress}%
            </label>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={goal.progress}
              onChange={(e) => handleProgressChange(parseInt(e.target.value))}
              className="slider w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <span className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center text-sm">
              📅
            </span>
            4-Week Roadmap
          </h3>

          <div className="space-y-4">
            <WeekSection weekNumber={1} content={goal.week1} />
            <WeekSection weekNumber={2} content={goal.week2} />
            <WeekSection weekNumber={3} content={goal.week3} />
            <WeekSection weekNumber={4} content={goal.week4} />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
