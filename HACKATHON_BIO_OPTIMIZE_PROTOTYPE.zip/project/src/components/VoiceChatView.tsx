import { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, Loader2, Target, Plus, Table } from 'lucide-react';
import { supabase, UserGoal, DailyMetrics } from '../lib/supabase';
import { generateFallbackResponse } from '../lib/fallbackAI';

type VoiceChatViewProps = {
  userId: string;
};

export function VoiceChatView({ userId }: VoiceChatViewProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [conversation, setConversation] = useState<Array<{ role: string; message: string }>>([]);
  const [goals, setGoals] = useState<UserGoal[]>([]);
  const [showGoalForm, setShowGoalForm] = useState(false);
  const [showAirtable, setShowAirtable] = useState(false);
  const [newGoal, setNewGoal] = useState({ title: '', description: '', goal_type: 'health' });
  const [sessionStart, setSessionStart] = useState<Date | null>(null);

  const recognitionRef = useRef<any>(null);
  const synthesisRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    loadGoals();
    initializeSpeechRecognition();
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [userId]);

  const loadGoals = async () => {
    const { data } = await supabase
      .from('user_goals')
      .select('*')
      .eq('user_id', userId)
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (data) setGoals(data);
  };

  const initializeSpeechRecognition = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const speechResult = event.results[0][0].transcript;
        setTranscript(speechResult);
        handleUserSpeech(speechResult);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  };

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in your browser. Please use Chrome or Edge.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      if (!sessionStart) setSessionStart(new Date());
      recognitionRef.current.start();
      setIsListening(true);
      setTranscript('');
    }
  };

  const handleUserSpeech = async (userMessage: string) => {
    setConversation(prev => [...prev, { role: 'user', message: userMessage }]);

    const today = new Date().toISOString().split('T')[0];
    const { data: metrics } = await supabase
      .from('daily_metrics')
      .select('*')
      .eq('user_id', userId)
      .eq('date', today)
      .maybeSingle();

    let aiResponse = '';

    try {
      const n8nUrl = import.meta.env.VITE_N8N_VOICE_WEBHOOK_URL;

      if (n8nUrl && n8nUrl !== 'https://your-n8n-instance.com/webhook/voice-chat') {
        const response = await fetch(n8nUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            user_id: userId,
            message: userMessage,
            goals: goals.map(g => ({
              id: g.id,
              title: g.title,
              description: g.description || '',
              goal_type: g.goal_type,
              status: g.status,
            })),
            metrics: metrics || {},
            conversation_history: conversation.slice(-5).map(c => ({
              role: c.role,
              content: c.message,
            })),
            session_start: sessionStart?.toISOString(),
          }),
        });

        if (!response.ok) {
          throw new Error(`Webhook failed: ${response.status}`);
        }

        const data = await response.json();
        aiResponse = data.response || data.message || data.text || generateFallbackResponse(userMessage, goals, metrics, conversation);
      } else {
        aiResponse = generateFallbackResponse(userMessage, goals, metrics, conversation);
      }
    } catch (error) {
      console.error('Voice webhook error:', error);
      aiResponse = generateFallbackResponse(userMessage, goals, metrics, conversation);
    }

    setResponse(aiResponse);
    setConversation(prev => [...prev, { role: 'assistant', message: aiResponse }]);
    speakResponse(aiResponse);

    await supabase.from('chat_history').insert({
      user_id: userId,
      mode: 'voice',
      message: userMessage,
      role: 'user',
    });

    await supabase.from('chat_history').insert({
      user_id: userId,
      mode: 'voice',
      message: aiResponse,
      role: 'assistant',
    });
  };

  const speakResponse = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1;
      utterance.volume = 1;

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      synthesisRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const saveSession = async () => {
    if (sessionStart && conversation.length > 0) {
      const duration = Math.floor((new Date().getTime() - sessionStart.getTime()) / 1000);
      const transcript = conversation.map(c => `${c.role}: ${c.message}`).join('\n');

      await supabase.from('voice_sessions').insert({
        user_id: userId,
        duration_seconds: duration,
        transcript,
      });
    }
  };

  const endSession = () => {
    saveSession();
    setConversation([]);
    setTranscript('');
    setResponse('');
    setSessionStart(null);
    stopSpeaking();
  };

  const addGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoal.title.trim()) return;

    await supabase.from('user_goals').insert({
      user_id: userId,
      title: newGoal.title,
      description: newGoal.description,
      goal_type: newGoal.goal_type,
    });

    setNewGoal({ title: '', description: '', goal_type: 'health' });
    setShowGoalForm(false);
    loadGoals();
  };

  const airtableUrl = import.meta.env.VITE_AIRTABLE_VOICE_SESSIONS_URL;

  return (
    <div className="h-full bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex">
      <div className="flex-1 flex flex-col">
        <div className="bg-gradient-to-r from-slate-900/90 to-slate-800/90 border-b border-slate-700/50 p-8 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-2">AI Voice Coach</h2>
              <p className="text-slate-400">Speak naturally - I'm always focused on your goals</p>
            </div>
            {airtableUrl && airtableUrl && airtableUrl !== 'https://airtable.com/embed/your-voice-sessions-view-id' && (
              <button
                onClick={() => setShowAirtable(!showAirtable)}
                className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50"
              >
                <Table size={20} />
                <span>{showAirtable ? 'Hide' : 'Show'} Table</span>
              </button>
            )}
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-8">
          <div className="max-w-2xl w-full">
            <div className="relative mb-12">
              <div className={`w-56 h-56 mx-auto rounded-full flex items-center justify-center transition-all duration-500 ${
                isListening
                  ? 'bg-gradient-to-br from-red-500/30 to-pink-500/30 animate-pulse shadow-2xl shadow-red-500/50'
                  : isSpeaking
                  ? 'bg-gradient-to-br from-blue-500/30 to-cyan-500/30 animate-pulse shadow-2xl shadow-blue-500/50'
                  : 'bg-gradient-to-br from-slate-800/50 to-slate-700/50 shadow-xl'
              }`}>
                <button
                  onClick={toggleListening}
                  disabled={isSpeaking}
                  className={`w-40 h-40 rounded-full flex items-center justify-center transition-all duration-300 shadow-2xl ${
                    isListening
                      ? 'bg-gradient-to-br from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 scale-110'
                      : 'bg-gradient-to-br from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 hover:scale-105 disabled:from-slate-600 disabled:to-slate-700 disabled:scale-100'
                  }`}
                >
                  {isListening ? <MicOff size={56} className="text-white" /> : <Mic size={56} className="text-white" />}
                </button>
              </div>

              {isSpeaking && (
                <button
                  onClick={stopSpeaking}
                  className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-slate-700 to-slate-600 hover:from-slate-600 hover:to-slate-500 text-white px-6 py-3 rounded-full text-sm font-medium flex items-center space-x-2 shadow-lg transition-all duration-300 hover:scale-105"
                >
                  <Volume2 size={18} />
                  <span>Stop Speaking</span>
                </button>
              )}
            </div>

            <div className="text-center mb-8">
              {isListening && (
                <div className="flex items-center justify-center space-x-2 text-red-400">
                  <Loader2 className="animate-spin" size={20} />
                  <span className="text-lg font-medium">Listening...</span>
                </div>
              )}
              {isSpeaking && (
                <div className="flex items-center justify-center space-x-2 text-blue-400">
                  <Volume2 size={20} />
                  <span className="text-lg font-medium">Speaking...</span>
                </div>
              )}
              {!isListening && !isSpeaking && (
                <span className="text-slate-400 text-lg">Tap the microphone to start</span>
              )}
            </div>

            {transcript && (
              <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 mb-4">
                <p className="text-sm text-slate-400 mb-1">You said:</p>
                <p className="text-white">{transcript}</p>
              </div>
            )}

            {response && (
              <div className="bg-blue-600/10 border border-blue-500/30 rounded-xl p-4">
                <p className="text-sm text-blue-400 mb-1">AI Coach:</p>
                <p className="text-white">{response}</p>
              </div>
            )}

            {conversation.length > 0 && (
              <button
                onClick={endSession}
                className="mt-6 w-full bg-slate-700 hover:bg-slate-600 text-white py-3 rounded-lg transition-colors"
              >
                End Session & Save
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="w-96 bg-slate-800 border-l border-slate-700 p-6 overflow-y-auto">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center">
              <Target className="mr-2" size={20} />
              Your Goals
            </h3>
            <button
              onClick={() => setShowGoalForm(!showGoalForm)}
              className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-lg transition-colors"
            >
              <Plus size={18} />
            </button>
          </div>

          {showGoalForm && (
            <form onSubmit={addGoal} className="bg-slate-700/50 rounded-lg p-4 mb-4 space-y-3">
              <input
                type="text"
                placeholder="Goal title"
                value={newGoal.title}
                onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                className="w-full px-3 py-2 bg-slate-600 border border-slate-500 rounded text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
              <textarea
                placeholder="Description"
                value={newGoal.description}
                onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                className="w-full px-3 py-2 bg-slate-600 border border-slate-500 rounded text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={2}
              />
              <select
                value={newGoal.goal_type}
                onChange={(e) => setNewGoal({ ...newGoal, goal_type: e.target.value })}
                className="w-full px-3 py-2 bg-slate-600 border border-slate-500 rounded text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="health">Health</option>
                <option value="mental">Mental</option>
                <option value="productivity">Productivity</option>
                <option value="short_term">Short Term</option>
                <option value="long_term">Long Term</option>
              </select>
              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded transition-colors text-sm"
              >
                Add Goal
              </button>
            </form>
          )}

          {goals.length === 0 ? (
            <p className="text-slate-400 text-sm">No active goals yet. Add your first goal!</p>
          ) : (
            <div className="space-y-3">
              {goals.map((goal) => (
                <div key={goal.id} className="bg-slate-700/50 rounded-lg p-3 border border-slate-600">
                  <h4 className="text-white font-medium text-sm mb-1">{goal.title}</h4>
                  {goal.description && (
                    <p className="text-slate-400 text-xs">{goal.description}</p>
                  )}
                  <span className="inline-block mt-2 text-xs px-2 py-1 bg-blue-600/20 text-blue-400 rounded">
                    {goal.goal_type}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {conversation.length > 0 && (
          <div className="border-t border-slate-700 pt-6">
            <h3 className="text-lg font-semibold text-white mb-4">Conversation</h3>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {conversation.map((msg, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded-lg text-sm ${
                    msg.role === 'user'
                      ? 'bg-blue-600/20 text-blue-100 ml-4'
                      : 'bg-slate-700/50 text-slate-200 mr-4'
                  }`}
                >
                  <p className="font-medium text-xs mb-1 opacity-70">
                    {msg.role === 'user' ? 'You' : 'AI Coach'}
                  </p>
                  <p>{msg.message}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {showAirtable && airtableUrl && airtableUrl && airtableUrl !== 'https://airtable.com/embed/your-voice-sessions-view-id' && (
          <div className="border-t border-slate-700 pt-6 mt-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
              <Table className="mr-2" size={20} />
              Voice Session Data
            </h3>
            <div className="bg-white rounded-xl overflow-hidden border border-slate-600 shadow-lg" style={{ height: '400px' }}>
              <iframe
                src={airtableUrl}
                className="w-full h-full"
                title="Airtable Voice Sessions"
              />
            </div>
            <p className="text-slate-500 text-xs mt-2">
              Synced from n8n automation - Updates automatically when sessions are saved
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
