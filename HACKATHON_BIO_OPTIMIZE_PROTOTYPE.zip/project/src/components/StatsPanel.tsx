import { useEffect, useState } from 'react';
import { supabase, Profile, Gamification, DailyMetrics } from '../lib/supabase';
import { Trophy, Flame, TrendingUp } from 'lucide-react';

type StatsPanelProps = {
  userId: string;
};

export function StatsPanel({ userId }: StatsPanelProps) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [gamification, setGamification] = useState<Gamification | null>(null);
  const [todayMetrics, setTodayMetrics] = useState<DailyMetrics | null>(null);

  useEffect(() => {
    loadData();
  }, [userId]);

  const loadData = async () => {
    const { data: profileData } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    const { data: gamificationData } = await supabase
      .from('gamification')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    const today = new Date().toISOString().split('T')[0];
    const { data: metricsData } = await supabase
      .from('daily_metrics')
      .select('*')
      .eq('user_id', userId)
      .eq('date', today)
      .maybeSingle();

    setProfile(profileData);
    setGamification(gamificationData);
    setTodayMetrics(metricsData);
  };

  if (!profile) return null;

  return (
    <div className="w-80 bg-slate-800 h-screen overflow-y-auto border-l border-slate-700 p-6 space-y-6">
      <div className="bg-slate-700/50 rounded-xl p-5 border border-slate-600">
        <h2 className="text-lg font-semibold text-white mb-4">Profile</h2>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-400">Name</span>
            <span className="text-white font-medium">{profile.name || 'Not set'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Height</span>
            <span className="text-white font-medium">{profile.height_cm || 0} cm</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Gender</span>
            <span className="text-white font-medium">{profile.gender || 'Not set'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Weight</span>
            <span className="text-white font-medium">{profile.weight_kg || 0} kg</span>
          </div>
        </div>
      </div>

      {gamification && (
        <div className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 rounded-xl p-5 border border-blue-500/30">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Trophy className="mr-2" size={20} />
            Gamification
          </h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-300">Level {gamification.level}</span>
                <span className="text-blue-400 font-medium">{gamification.xp} XP</span>
              </div>
              <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-blue-400 transition-all duration-500"
                  style={{ width: `${(gamification.xp % 100)}%` }}
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-blue-500/20">
              <div className="flex items-center">
                <Flame className="text-orange-400 mr-2" size={20} />
                <span className="text-slate-300 text-sm">Current Streak</span>
              </div>
              <span className="text-white font-bold text-lg">{gamification.current_streak}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <TrendingUp className="text-green-400 mr-2" size={20} />
                <span className="text-slate-300 text-sm">Best Streak</span>
              </div>
              <span className="text-white font-bold text-lg">{gamification.longest_streak}</span>
            </div>
          </div>
        </div>
      )}

      {todayMetrics && (
        <div className="bg-slate-700/50 rounded-xl p-5 border border-slate-600">
          <h2 className="text-lg font-semibold text-white mb-4">Today's Metrics</h2>
          <div className="space-y-3 text-sm">
            <MetricRow label="Mood" value={todayMetrics.mood_score_1_10} max={10} />
            <MetricRow label="Energy" value={todayMetrics.energy_level_1_10} max={10} />
            <MetricRow label="Sleep Quality" value={todayMetrics.sleep_quality_1_10} max={10} />
            <MetricRow label="Stress" value={todayMetrics.stress_level_1_10} max={10} invert />
            <div className="pt-3 border-t border-slate-600 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Steps</span>
                <span className="text-white font-medium">{todayMetrics.steps_per_day.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Water</span>
                <span className="text-white font-medium">{todayMetrics.water_intake_liters}L</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Exercise</span>
                <span className="text-white font-medium">{todayMetrics.exercise_minutes}min</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MetricRow({ label, value, max, invert = false }: { label: string; value: number; max: number; invert?: boolean }) {
  const percentage = (value / max) * 100;
  const color = invert
    ? percentage > 66 ? 'bg-red-500' : percentage > 33 ? 'bg-yellow-500' : 'bg-green-500'
    : percentage > 66 ? 'bg-green-500' : percentage > 33 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-slate-400">{label}</span>
        <span className="text-white font-medium">{value}/{max}</span>
      </div>
      <div className="h-1.5 bg-slate-600 rounded-full overflow-hidden">
        <div className={`h-full ${color} transition-all duration-500`} style={{ width: `${percentage}%` }} />
      </div>
    </div>
  );
}
