import { useState, useEffect, useCallback, useRef } from 'react';
import { Goal, CachedData } from '../types/airtableGoal';
import { airtableClient } from '../lib/airtableClient';
import { mockGoals } from '../lib/mockGoalsData';

const CACHE_KEY = 'airtable_goals_cache';
const POLLING_INTERVAL = 60000;

export function useAirtableGoals() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastSyncedAt, setLastSyncedAt] = useState<Date | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [syncing, setSyncing] = useState(false);
  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const loadFromCache = useCallback((): Goal[] | null => {
    try {
      const cached = localStorage.getItem(CACHE_KEY);
      if (!cached) return null;

      const data: CachedData = JSON.parse(cached);
      setLastSyncedAt(new Date(data.lastSyncedAt));
      return data.goals;
    } catch (error) {
      console.error('Failed to load cache:', error);
      return null;
    }
  }, []);

  const saveToCache = useCallback((goals: Goal[]) => {
    try {
      const data: CachedData = {
        goals,
        lastSyncedAt: new Date().toISOString(),
      };
      localStorage.setItem(CACHE_KEY, JSON.stringify(data));
      setLastSyncedAt(new Date());
    } catch (error) {
      console.error('Failed to save cache:', error);
    }
  }, []);

  const fetchGoals = useCallback(async (showLoading = true) => {
    if (showLoading) {
      setSyncing(true);
    }
    setError(null);

    try {
      let fetchedGoals: Goal[];

      if (airtableClient.isConfigured()) {
        fetchedGoals = await airtableClient.listGoals();
      } else {
        console.warn('Airtable not configured, using mock data');
        fetchedGoals = mockGoals;
      }

      setGoals(fetchedGoals);
      saveToCache(fetchedGoals);
      setIsOnline(true);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch goals';
      setError(errorMessage);
      setIsOnline(false);

      const cached = loadFromCache();
      if (cached) {
        setGoals(cached);
      }
    } finally {
      if (showLoading) {
        setLoading(false);
        setSyncing(false);
      }
    }
  }, [loadFromCache, saveToCache]);

  const updateGoal = useCallback(
    async (goalId: string, updates: Partial<Goal>): Promise<boolean> => {
      const originalGoals = [...goals];
      const goalIndex = goals.findIndex((g) => g.id === goalId);

      if (goalIndex === -1) return false;

      const updatedGoal = { ...goals[goalIndex], ...updates };
      const newGoals = [...goals];
      newGoals[goalIndex] = updatedGoal;
      setGoals(newGoals);

      try {
        const airtableUpdates: any = {};
        if (updates.status !== undefined) airtableUpdates.Status = updates.status;
        if (updates.progress !== undefined) airtableUpdates.Progress = updates.progress;

        if (airtableClient.isConfigured()) {
          await airtableClient.updateGoal(goalId, airtableUpdates);
        }

        saveToCache(newGoals);
        return true;
      } catch (err) {
        console.error('Failed to update goal:', err);
        setGoals(originalGoals);
        setError(err instanceof Error ? err.message : 'Failed to update goal');
        return false;
      }
    },
    [goals, saveToCache]
  );

  const manualRefresh = useCallback(() => {
    return fetchGoals(true);
  }, [fetchGoals]);

  useEffect(() => {
    const cached = loadFromCache();
    if (cached && cached.length > 0) {
      setGoals(cached);
      setLoading(false);
    }

    fetchGoals(cached === null || cached.length === 0);

    pollingIntervalRef.current = setInterval(() => {
      fetchGoals(false);
    }, POLLING_INTERVAL);

    const handleOnline = () => {
      setIsOnline(true);
      fetchGoals(false);
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [fetchGoals, loadFromCache]);

  return {
    goals,
    loading,
    error,
    lastSyncedAt,
    isOnline,
    syncing,
    updateGoal,
    manualRefresh,
  };
}
