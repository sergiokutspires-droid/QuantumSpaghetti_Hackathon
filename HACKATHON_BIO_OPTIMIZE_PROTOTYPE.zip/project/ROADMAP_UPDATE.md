# Roadmap View Update

## ✨ Changes Made

### 1. **Menu Items Swapped**
The sidebar navigation has been updated:
- **"Goals & Roadmap"** → Now shows the beautiful new roadmap design
- **"My Goals"** → Now shows the Airtable goals management view

### 2. **New Roadmap Design**
The Goals & Roadmap section now features:

#### Visual Design
- **Animated star background** with 100 twinkling stars
- **3 floating gradient orbs** (cyan, purple, pink)
- **Glass morphism UI** with frosted backdrop effects
- **Smooth animations** - fade-in, slide-in effects
- **Gradient shimmer** on main goal card

#### Layout Components
1. **Top Bar**
   - "BIO_HACKING ENLIGHTENMENT" branding
   - Current date display

2. **Main Goal Card**
   - Large prominent card with purple border
   - Animated shimmer effect on top
   - Sparkles icon with "MAIN GOAL" label
   - Displays user's primary goal from Supabase
   - Shows goal description if available

3. **Weekly Steps Timeline**
   - Vertical gradient connector line
   - 4 weekly goal cards (W1, W2, W3, W4)
   - Each week has unique gradient:
     - Week 1: Cyan → Blue
     - Week 2: Blue → Purple
     - Week 3: Purple → Pink
     - Week 4: Pink → Red
   - Hover effects (lift and translate)
   - Staggered slide-in animations

### 3. **Airtable Integration**
The roadmap now connects directly to Airtable:

#### Configuration
```javascript
const AIRTABLE_CONFIG = {
  baseId: 'appaYblbQ3dObzWvT',
  tableIdOrName: 'tblIfOBzzbY2ugOr3',
  apiKey: 'patoQtjKJEdnCfgI7.bffdc01beb04c9ba56322044d83de66ef1dfcd88112ec0981178dcbcbb54d863',
};
```

#### Data Flow
```
User opens Goals & Roadmap
    ↓
Load active goal from Supabase
    ↓
Fetch from Airtable using goal title
    ↓
Query: SEARCH("goal title", {Goal})
    ↓
Extract weekly steps from fields:
  - Goal WEEK1
  - Goal WEEK2
  - Goal WEEK3
  - Goal WEEK4
    ↓
Display in beautiful timeline
```

#### Airtable Table Structure
The system expects the following fields in your Airtable table:
- **Name** (text) - User name for filtering
- **Goal** (text) - Main goal description
- **Goal WEEK1** (text) - Week 1 performance goal
- **Goal WEEK2** (text) - Week 2 performance goal
- **Goal WEEK3** (text) - Week 3 performance goal
- **Goal WEEK4** (text) - Week 4 performance goal

### 4. **Data Sources**

#### Primary: Supabase
- Fetches user's **active goal** from `user_goals` table
- Uses goal title and description
- Queries: `status = 'active'`, sorted by `created_at`

#### Secondary: Airtable
- Fetches **weekly breakdown** from Airtable
- Matches goal by title using SEARCH formula
- Falls back to generic roadmap if not found

### 5. **Fallback System**
If Airtable data is unavailable, shows generic weekly goals:
- **Week 1**: Foundation & Assessment
- **Week 2**: Building Momentum
- **Week 3**: Optimization & Growth
- **Week 4**: Mastery & Planning Ahead

### 6. **Empty States**
Beautiful empty state displays when:
- No active goals in Supabase
- No matching records in Airtable
- Shows helpful message with map emoji 🗺️

## 🎯 How It Works

### User Flow
1. User navigates to **"Goals & Roadmap"** in sidebar
2. System fetches active goal from Supabase
3. System queries Airtable with goal title
4. Weekly steps extracted from Airtable fields
5. Beautiful roadmap renders with animations
6. User sees their personalized journey

### Example Data Flow
```
Supabase Goal: "Lose twenty kilograms"
    ↓
Airtable Query: SEARCH("Lose twenty kilograms", {Goal})
    ↓
Finds Record:
  - Name: "John"
  - Goal: "Lose twenty kilograms"
  - Goal WEEK1: "Commit to daily 10,000 steps..."
  - Goal WEEK2: "Establish meal prep routine..."
  - Goal WEEK3: "Add 3 strength training sessions..."
  - Goal WEEK4: "Create 7-8 hour sleep schedule..."
    ↓
Displays Timeline:
  🎯 Main Goal: Lose twenty kilograms
  W1 ─ Commit to daily 10,000 steps...
  W2 ─ Establish meal prep routine...
  W3 ─ Add 3 strength training sessions...
  W4 ─ Create 7-8 hour sleep schedule...
```

## 🔧 Technical Details

### Component Structure
```
RoadmapView.tsx
├── Star background (100 animated stars)
├── Gradient orbs (3 floating orbs)
├── Top bar (branding + date)
├── Main goal card (from Supabase)
└── Weekly steps timeline (from Airtable)
    ├── W1 (Cyan gradient)
    ├── W2 (Purple gradient)
    ├── W3 (Pink gradient)
    └── W4 (Red gradient)
```

### API Integration
```typescript
// Fetch from Supabase
const { data: goals } = await supabase
  .from('user_goals')
  .select('*')
  .eq('user_id', userId)
  .eq('status', 'active')
  .order('created_at', { ascending: false })
  .limit(1);

// Fetch from Airtable
const filterFormula = `SEARCH("${goalTitle}", {Goal})`;
const url = `https://api.airtable.com/v0/${baseId}/${tableId}?filterByFormula=${encodeURIComponent(filterFormula)}`;

const response = await fetch(url, {
  headers: {
    Authorization: `Bearer ${apiKey}`,
  },
});
```

### Animation Keyframes
```css
@keyframes twinkle {
  0%, 100% { opacity: 0.3; transform: scale(1); }
  50% { opacity: 1; transform: scale(1.5); }
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) rotate(0deg); }
  33% { transform: translate(30px, -30px) rotate(120deg); }
  66% { transform: translate(-20px, 20px) rotate(240deg); }
}

@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

@keyframes slideInLeft {
  from { opacity: 0; transform: translateX(-30px); }
  to { opacity: 1; transform: translateX(0); }
}
```

## 📊 Airtable Setup Guide

### Required Fields
Ensure your Airtable table has these fields:

| Field Name | Type | Description |
|------------|------|-------------|
| Name | Single line text | User's name for filtering |
| Goal | Long text | Main goal description |
| Goal WEEK1 | Long text | Week 1 performance goal |
| Goal WEEK2 | Long text | Week 2 performance goal |
| Goal WEEK3 | Long text | Week 3 performance goal |
| Goal WEEK4 | Long text | Week 4 performance goal |

### Example Record
```
Name: John
Goal: Lose twenty kilograms
Goal WEEK1: Commit to a daily step target of 10,000 steps and track your progress
Goal WEEK2: Establish a consistent meal prep routine for healthier eating habits
Goal WEEK3: Add 3 strength training sessions per week to build muscle
Goal WEEK4: Create a sleep schedule aiming for 7-8 hours per night
```

## 🎨 Design Features

### Colors
- **Background**: Dark blue gradient (#0a1628 → #0d1b2a → #0a1520)
- **Main Goal**: Purple gradient with shimmer
- **Week 1**: Cyan → Blue
- **Week 2**: Blue → Purple
- **Week 3**: Purple → Pink
- **Week 4**: Pink → Red

### Effects
- **Glass Morphism**: `backdrop-filter: blur(20px)` with semi-transparent backgrounds
- **Glow Effects**: Color-matched shadows on week badges
- **Hover States**: Cards lift and translate on hover
- **Smooth Transitions**: All animations use `ease` timing

### Responsive Design
- Works on mobile and desktop
- Adjusts padding and font sizes
- Maintains animations on all screen sizes

## ✅ Testing Checklist

- [x] Menu items swapped correctly
- [x] Roadmap shows in "Goals & Roadmap"
- [x] Airtable goals show in "My Goals"
- [x] Fetches active goals from Supabase
- [x] Queries Airtable with goal title
- [x] Displays weekly steps correctly
- [x] Shows empty state when no data
- [x] Fallback works when Airtable unavailable
- [x] Animations work smoothly
- [x] Responsive on mobile
- [x] Build succeeds without errors

## 🚀 What's Next

### Potential Enhancements
1. **User name configuration** - Let users set their Airtable name in profile
2. **Progress tracking** - Check off completed weeks
3. **Week details** - Expand each week to show tasks
4. **Multiple goals** - Support multiple active goals
5. **Edit mode** - Update Airtable directly from UI
6. **Sync status** - Show last sync time
7. **Manual refresh** - Button to reload from Airtable
8. **Goal history** - View past completed goals

## 📝 Notes

- **CORS**: Direct browser calls to Airtable API work because we're using a Personal Access Token
- **Security**: API key is in `.env` but should be moved to backend proxy in production
- **Performance**: Airtable calls are made only when navigating to the view
- **Caching**: Consider adding local storage cache for offline viewing
- **Error Handling**: Graceful fallbacks ensure app never breaks

---

**Enjoy your beautiful new roadmap! 🗺️✨**
