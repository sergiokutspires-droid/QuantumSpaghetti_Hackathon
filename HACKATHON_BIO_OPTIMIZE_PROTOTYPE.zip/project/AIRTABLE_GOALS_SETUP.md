# Airtable Goals & Roadmap Setup Guide

## Overview

The Airtable Goals feature provides a synchronized goals management system with week-by-week roadmaps. It treats Airtable as the source of truth and automatically syncs every 60 seconds.

## Features

✅ **Real-time Synchronization**
- Polls Airtable every 60 seconds
- Manual refresh button
- Offline support with cached data
- Shows last sync timestamp

✅ **Rich UI with Animations**
- Smooth Framer Motion animations
- Click-to-expand goal details
- Collapsible week sections
- Progress bars and status indicators

✅ **Search & Filter**
- Search goals by title
- Filter by status (Not Started, In Progress, Done)
- Real-time filtering

✅ **Week-by-Week Roadmap**
- 4-week breakdown per goal
- Markdown support for formatting
- Copy-to-clipboard functionality
- Keyboard accessible accordions

✅ **Optimistic Updates**
- Update status and progress in UI
- Automatic rollback on error
- Throttled API calls

## Airtable Setup

### 1. Create Your Airtable Base

Your Airtable base should have the following structure:

**Table Name:** (Your choice, e.g., "Goals")

**Required Fields:**
- `Goal` (Single line text) - The goal title
- `Week_1` (Long text) - Week 1 action plan
- `Week_2` (Long text) - Week 2 action plan
- `Week_3` (Long text) - Week 3 action plan
- `Week_4` (Long text) - Week 4 action plan

**Optional Fields:**
- `Goal_Description` (Long text) - Detailed description
- `Status` (Single select) - Options: "Not Started", "In Progress", "Done"
- `Progress` (Number 0-100) - Completion percentage

### 2. Get Your Airtable Credentials

1. **Get Personal Access Token:**
   - Go to https://airtable.com/create/tokens
   - Click "Create new token"
   - Give it a name (e.g., "Goals App")
   - Add these scopes:
     - `data.records:read`
     - `data.records:write`
   - Add access to your base
   - Copy the token

2. **Get Base ID:**
   - Open your Airtable base
   - URL format: `https://airtable.com/{BASE_ID}/...`
   - Copy the BASE_ID (starts with "app")

3. **Get Table ID:**
   - Click "..." on your table
   - Click "Copy table ID"
   - Paste the table ID (starts with "tbl")

4. **Get View ID (Optional):**
   - Open the view you want to use
   - Click "..." on the view
   - Click "Copy view ID"
   - Paste the view ID (starts with "viw")

### 3. Configure Environment Variables

Update your `.env` file:

```env
VITE_AIRTABLE_BASE_ID=appaYblbQ3dObzWvT
VITE_AIRTABLE_TABLE_ID=tblIfOBzzbY2ugOr3
VITE_AIRTABLE_VIEW_ID=viwYxDhiFKI4psZl3
VITE_AIRTABLE_API_KEY=your-personal-access-token-here
```

## Field Name Customization

If your Airtable fields have different names, update them in:

`src/lib/airtableFieldMapping.ts`

```typescript
export const AIRTABLE_FIELD_NAMES = {
  GOAL: 'Goal',                    // Change to your field name
  GOAL_DESCRIPTION: 'Goal_Description',
  WEEK_1: 'Week_1',
  WEEK_2: 'Week_2',
  WEEK_3: 'Week_3',
  WEEK_4: 'Week_4',
  STATUS: 'Status',
  PROGRESS: 'Progress',
} as const;
```

## Mock Mode (Development)

If you don't have Airtable configured, the app will automatically use mock data. This allows you to:
- Test the UI without Airtable
- Develop features locally
- Demo the application

To enable mock mode, either:
- Don't set the environment variables, or
- Leave them as the default placeholder values

## Usage

### Viewing Goals

1. Navigate to "Goals & Roadmap" in the sidebar
2. Browse your goals in the left panel
3. Click any goal to view its 4-week roadmap
4. Each week can be expanded to see details

### Searching & Filtering

- Use the search box to find goals by title
- Use the status dropdown to filter by progress
- Filters work in real-time

### Updating Goals

- Click the status dropdown to change goal status
- Use the progress slider to update completion percentage
- Changes sync to Airtable automatically

### Copying Plans

- Expand any week section
- Click "Copy plan" to copy the text
- Paste into notes, emails, or other apps

### Manual Refresh

- Click the "Refresh" button to sync immediately
- Automatic sync happens every 60 seconds
- Shows "Syncing..." indicator during updates

## Offline Support

When offline:
- Shows cached data from last successful sync
- Displays "Offline" indicator
- Shows timestamp of last sync
- Re-syncs automatically when back online

## Rate Limiting

The app handles Airtable rate limits automatically:
- Retries failed requests with exponential backoff
- Throttles update requests
- Shows error messages if rate limited

## Error Handling

- Shows non-blocking error toasts
- Falls back to cached data on fetch errors
- Optimistic UI updates with rollback
- Console logs for debugging

## Performance

- **Caching:** Local storage caching for instant load
- **Pagination:** Handles large datasets automatically
- **Virtualization:** Efficient rendering for 100+ goals
- **Debouncing:** Throttled API calls to prevent overload

## Accessibility

- Keyboard navigation for all interactions
- ARIA labels and attributes
- Focus management for modals
- Semantic HTML structure

## Troubleshooting

### "Airtable not configured" Error

**Solution:** Check your `.env` file and ensure all credentials are correct.

### Goals Not Updating

**Solution:**
1. Check browser console for errors
2. Verify your Personal Access Token has write permissions
3. Try manual refresh

### Slow Loading

**Solution:**
1. Check your internet connection
2. Verify Airtable API status
3. Clear browser cache and localStorage

### "No goals found"

**Solution:**
1. Check your Airtable view isn't filtered
2. Verify table and view IDs are correct
3. Ensure at least one record exists

## Architecture

```
src/
├── components/
│   ├── AirtableGoalsView.tsx          # Main container
│   └── airtable/
│       ├── GoalCard.tsx               # Individual goal card
│       ├── GoalDetailsPanel.tsx       # Goal details + weeks
│       ├── WeekSection.tsx            # Collapsible week content
│       ├── SearchAndFilters.tsx       # Search & filter UI
│       └── SyncIndicator.tsx          # Sync status display
├── hooks/
│   └── useAirtableGoals.ts            # Data fetching hook
├── lib/
│   ├── airtableClient.ts              # API client
│   ├── airtableFieldMapping.ts        # Field name constants
│   ├── mockGoalsData.ts               # Mock data for dev
│   └── dateUtils.ts                   # Date formatting
└── types/
    └── airtableGoal.ts                # TypeScript types
```

## Best Practices

1. **Keep field names in constants** - Never hardcode field names in components
2. **Use TypeScript types** - Ensure type safety across the app
3. **Handle errors gracefully** - Always provide fallbacks
4. **Cache aggressively** - Improve perceived performance
5. **Test offline behavior** - Ensure app works without internet

## Support

For issues or questions:
1. Check browser console for errors
2. Verify Airtable credentials
3. Test with mock data mode
4. Review this documentation

---

Built with React, TypeScript, Tailwind CSS, Framer Motion, and the Airtable API.
