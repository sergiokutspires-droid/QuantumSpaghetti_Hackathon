# BioHacking Enlightenment Integration Guide

This guide explains the integration of the HTML "BioHacking Enlightenment" project into your React application.

## ✨ What Was Integrated

### 1. **ElevenLabs Voice AI**
Real-time voice conversations with AI using the ElevenLabs Conversational AI SDK.

**Location**: `src/components/EnlightenmentView.tsx`

**Features**:
- Live voice input/output
- Real-time transcription
- Natural conversation flow
- Session management
- Webhook integration with n8n

### 2. **Crystal Orb Visualization**
Beautiful animated crystal interface that serves as the conversation trigger.

**Visual Features**:
- Animated gradient background
- Breathing animation effect
- Pulse glow when active
- Sparkle effects
- Mode-specific colors (cyan for Goal, purple for Wellness)

### 3. **Dual AI Modes**
Two distinct AI coaching personalities:

**Goal Crystal Mode** 🚀
- Strategic guidance
- Performance acceleration
- Achievement-focused
- Cyan color theme

**Wellness Coach Mode** 🧠
- Emotional balance
- Mental health support
- Well-being focused
- Purple/teal color theme

### 4. **Animated Background**
150 twinkling stars create an immersive cosmic atmosphere.

### 5. **Stats Dashboard**
Four metrics cards showing:
- Focus Power ⚡
- Flow Streak 🔥
- Balance 🌿
- Progress 🧭

## 🎯 How to Access

Navigate to **Enlightenment** in the sidebar (first menu item with sparkles icon ✨)

## 🔧 Configuration

### Environment Variables

Add these to your `.env` file:

```env
# ElevenLabs AI Agents
VITE_ELEVENLABS_GOAL_AGENT_ID=agent_2301k9ffgscte5zrsh4tntnwnr72
VITE_ELEVENLABS_WELLNESS_AGENT_ID=agent_3601k9fsz3a2e93vt7pm6v0skmmb

# n8n Webhooks (optional - for logging/tracking)
VITE_N8N_GOAL_WEBHOOK=https://your-n8n.app.n8n.cloud/webhook/goals
VITE_N8N_WELLNESS_WEBHOOK=https://your-n8n.app.n8n.cloud/webhook/wellness
```

### Getting ElevenLabs Agent IDs

1. Go to [ElevenLabs](https://elevenlabs.io/)
2. Create an account or sign in
3. Navigate to "Conversational AI" section
4. Create two agents:
   - **Goal Crystal**: Configure with goal-oriented prompts
   - **Wellness Coach**: Configure with empathetic, supportive prompts
5. Copy the Agent IDs (format: `agent_xxxxxxxxxxxxxxxxxxxxx`)
6. Add to your `.env` file

### Customizing Agent Personalities

In ElevenLabs dashboard, set these system prompts:

**Goal Crystal**:
```
You are an elite performance coach and strategic advisor. Help users achieve their goals through:
- Clear action steps
- Accountability
- Strategic thinking
- Performance optimization
- Time management
- Habit formation

Be direct, motivating, and results-focused. Ask clarifying questions to understand their goals deeply.
```

**Wellness Coach**:
```
You are a compassionate mental wellness coach. Support users through:
- Active listening
- Emotional validation
- Stress management techniques
- Work-life balance
- Self-care practices
- Mindfulness guidance

Be warm, empathetic, and non-judgmental. Create a safe space for sharing.
```

## 🎮 User Flow

### First Time Experience

1. **Select Mode**: User clicks either "Goal Crystal" or "Wellness Coach"
2. **Crystal Activates**: Orb changes color based on mode
3. **Click Crystal**: Initiates voice connection
4. **Grant Permissions**: Browser asks for microphone access
5. **Start Speaking**: AI listens and responds in real-time

### During Conversation

- **Crystal Animation**: Orb pulses and glows while active
- **Status Updates**: Shows "Listening" or "Speaking" state
- **Messages Display**: Short preview of AI responses
- **Visual Feedback**: Color-coded states

### Ending Session

- Click crystal again or wait for natural conversation end
- Session data sent to n8n webhook (if configured)
- Stats reset for next session

## 🔗 Integration with Existing Features

### Connection to Goals System

The voice conversations can reference:
- User's active goals from Supabase
- Recent metrics from tracking
- Progress on roadmap items

**To enable**: Update webhook handlers to query Supabase for user data.

### Connection to Tracking

Voice sessions can automatically:
- Log mood scores
- Record stress levels
- Track conversation insights
- Update daily metrics

**To enable**: Parse conversation content in n8n and update Supabase tables.

### Connection to Analytics

Session data can feed into:
- Power BI dashboards
- Airtable logs
- Progress reports

**To enable**: Configure n8n workflows to forward data to analytics tools.

## 🛠️ Technical Architecture

### Component Structure

```
EnlightenmentView.tsx
├── Stars Background (animated)
├── Mode Selection Cards
│   ├── Goal Crystal Button
│   └── Wellness Coach Button
├── Crystal Orb (main interaction)
│   ├── Gradient Background
│   ├── Sparkle Effects
│   └── Click Handler
├── Status Display
│   ├── Primary Metric
│   └── Agent Message
└── Stats Cards
    ├── Focus Power
    ├── Flow Streak
    ├── Balance
    └── Progress
```

### Data Flow

```
User Speaks
    ↓
Microphone → ElevenLabs SDK → AI Agent → Voice Response
    ↓                                      ↓
n8n Webhook                         User Hears
    ↓
Supabase (optional logging)
    ↓
Analytics/Airtable (optional)
```

### State Management

```typescript
selectedMode: 'goal' | 'wellness' | null
isConversationActive: boolean
isLoading: boolean
primaryMetric: string
agentMessage: string
conversationRef: ElevenLabs Conversation object
```

## 🎨 Customization Options

### Colors

Edit in `EnlightenmentView.tsx`:

```typescript
// Goal mode colors
from-cyan-400 via-purple-500 to-pink-400

// Wellness mode colors
from-teal-400 via-purple-500 to-pink-500
```

### Animations

Adjust animation durations:

```css
@keyframes breathe {
  /* Change 8s to your preference */
  animation: breathe 8s ease-in-out infinite;
}
```

### Star Count

Change number of background stars:

```typescript
for (let i = 0; i < 150; i++) {
  // Reduce for better performance
  // Increase for more immersive feel
}
```

## 🐛 Troubleshooting

### Issue: Crystal doesn't respond to clicks
**Solution**: Check browser console for ElevenLabs SDK loading errors. Ensure the CDN script is loading in `index.html`.

### Issue: Microphone not working
**Solution**:
- Check browser permissions (chrome://settings/content/microphone)
- Use HTTPS (required for microphone access)
- Test with `navigator.mediaDevices.getUserMedia()`

### Issue: No voice response
**Solution**:
- Verify Agent IDs are correct
- Check ElevenLabs account has credits
- Inspect network tab for API errors
- Ensure agent is published/active in ElevenLabs dashboard

### Issue: Webhook not receiving data
**Solution**:
- Test webhook URL with curl/Postman
- Check n8n workflow is activated
- Verify CORS settings if needed
- Look at n8n execution logs

## 📱 Mobile Considerations

The Enlightenment view is responsive but voice features require:
- Modern mobile browser (Chrome/Safari recommended)
- Microphone permissions granted
- Stable internet connection
- Sufficient data/wifi speed

**Note**: Some mobile browsers restrict microphone in background tabs.

## 🔒 Privacy & Security

### Data Handling

Voice data flows through:
1. **User's Browser** → Microphone input
2. **ElevenLabs** → Voice processing & AI
3. **n8n** (optional) → Logging/automation
4. **Supabase** (optional) → Storage

### User Privacy

- Voice is processed in real-time, not stored by default
- Enable logging only if needed for analytics
- Inform users about data collection
- Follow GDPR/privacy regulations

### Security Best Practices

- Keep Agent IDs in environment variables
- Use HTTPS for all connections
- Implement rate limiting on webhooks
- Monitor for unusual usage patterns
- Regularly rotate API keys

## 🚀 Future Enhancements

### Possible Additions

1. **Session History**: Store and replay past conversations
2. **Emotion Detection**: Analyze voice tone/sentiment
3. **Multi-language**: Support multiple languages
4. **Custom Voices**: Select different AI voice personalities
5. **Conversation Summaries**: Auto-generate session insights
6. **Goal Extraction**: Parse goals mentioned in conversation
7. **Smart Reminders**: Schedule follow-ups based on conversation
8. **Team Sessions**: Multi-user conversations
9. **Transcript Export**: Download conversation as text/PDF
10. **Voice Commands**: "Set a goal", "Track my mood", etc.

## 📊 Success Metrics

Track these to measure effectiveness:

- Average session duration
- Conversations per user per week
- Mode preference (Goal vs Wellness)
- User retention after first session
- Goal completion rates
- User satisfaction scores
- Feature adoption rate

## 🤝 Support & Resources

- [ElevenLabs Documentation](https://elevenlabs.io/docs)
- [ElevenLabs Conversational AI](https://elevenlabs.io/docs/conversational-ai)
- [n8n Workflow Templates](https://n8n.io/workflows)
- [Supabase Real-time](https://supabase.com/docs/guides/realtime)

## 📝 Code Examples

### Accessing User Data in Conversation

```typescript
// In startConversation() function
const { data: goals } = await supabase
  .from('user_goals')
  .select('*')
  .eq('user_id', userId)
  .eq('status', 'active');

await sendWebhookData(webhookUrl, {
  event: 'conversation_started',
  userId,
  goals: goals || [],
  // ... other data
});
```

### Custom Message Handler

```typescript
onMessage: (message: any) => {
  // Parse for specific keywords
  if (message.message.includes('goal')) {
    // Trigger goal-related action
  }

  // Store in state
  setAgentMessage(message.message);

  // Send to analytics
  trackEvent('ai_message_received', {
    mode: selectedMode,
    length: message.message.length
  });
}
```

### Error Recovery

```typescript
onError: (error: Error) => {
  // Log to monitoring service
  console.error('ElevenLabs error:', error);

  // Notify user
  displayMessage('Connection lost. Retrying...', 'error');

  // Attempt reconnection
  setTimeout(() => {
    if (!isConversationActive) {
      startConversation();
    }
  }, 3000);
}
```

---

**Enjoy your new Enlightenment experience! 🌟**
